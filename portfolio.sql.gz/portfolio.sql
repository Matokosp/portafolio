-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 27-01-2019 a las 02:10:21
-- Versión del servidor: 5.6.34-log
-- Versión de PHP: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `portfolio`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pf_commentmeta`
--

CREATE TABLE `pf_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pf_comments`
--

CREATE TABLE `pf_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `pf_comments`
--

INSERT INTO `pf_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-01-22 21:47:55', '2019-01-22 21:47:55', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pf_ewwwio_images`
--

CREATE TABLE `pf_ewwwio_images` (
  `id` int(14) UNSIGNED NOT NULL,
  `attachment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `gallery` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `resize` varchar(75) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `path` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `converted` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `results` varchar(75) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `image_size` int(10) UNSIGNED DEFAULT NULL,
  `orig_size` int(10) UNSIGNED DEFAULT NULL,
  `backup` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `level` int(5) UNSIGNED DEFAULT NULL,
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `updates` int(5) UNSIGNED DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT '1971-01-01 03:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `trace` blob
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `pf_ewwwio_images`
--

INSERT INTO `pf_ewwwio_images` (`id`, `attachment_id`, `gallery`, `resize`, `path`, `converted`, `results`, `image_size`, `orig_size`, `backup`, `level`, `pending`, `updates`, `updated`, `trace`) VALUES
(1, 24, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/apple-touch-icon-180x180.png', '', 'Reduced by 15.2% (1.0 KB)', 5785, 6822, '', 10, 0, 1, '2019-01-24 06:14:11', NULL),
(2, 24, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/apple-touch-icon-180x180-150x150.png', '', 'Reduced by 2.0% (118 B)', 5680, 5798, '', 10, 0, 1, '2019-01-24 06:14:12', NULL),
(3, 27, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/home-slide-3.jpg', '', 'Reduced by 2.0% (1.2 KB)', 59518, 60731, '', 10, 0, 1, '2019-01-24 06:18:12', NULL),
(4, 27, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/home-slide-3-150x150.jpg', '', 'Reduced by 9.8% (825 B)', 7605, 8430, '', 10, 0, 1, '2019-01-24 06:18:13', NULL),
(5, 27, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/home-slide-3-139x300.jpg', '', 'Reduced by 8.0% (1.0 KB)', 11711, 12736, '', 10, 0, 1, '2019-01-24 06:18:15', NULL),
(6, 27, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/home-slide-3-450x600.jpg', '', 'Reduced by 4.0% (2.0 KB)', 49772, 51846, '', 10, 0, 1, '2019-01-24 06:18:16', NULL),
(7, 30, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/home-slide-1.jpg', '', 'Reduced by 3.6% (3.4 KB)', 93857, 97334, '', 10, 0, 1, '2019-01-24 06:19:57', NULL),
(8, 30, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/home-slide-1-150x150.jpg', '', 'Reduced by 11.5% (825 B)', 6366, 7191, '', 10, 0, 1, '2019-01-24 06:19:57', NULL),
(9, 30, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/home-slide-1-139x300.jpg', '', 'Reduced by 8.2% (916 B)', 10206, 11122, '', 10, 0, 1, '2019-01-24 06:19:58', NULL),
(10, 30, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/home-slide-1-450x600.jpg', '', 'Reduced by 4.6% (3.4 KB)', 72571, 76094, '', 10, 0, 1, '2019-01-24 06:19:59', NULL),
(11, 32, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/home-slide-1-1.jpg', '', 'Reduced by 2.0% (961 B)', 47409, 48370, '', 10, 0, 1, '2019-01-24 06:20:58', NULL),
(12, 32, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/home-slide-1-1-150x150.jpg', '', 'No savings', 4749, 4749, '', 10, 0, 1, '2019-01-24 06:20:59', NULL),
(13, 32, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/home-slide-1-1-139x300.jpg', '', 'No savings', 7385, 7385, '', 10, 0, 1, '2019-01-24 06:21:00', NULL),
(14, 32, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/home-slide-1-1-450x600.jpg', '', 'Reduced by 3.5% (1.5 KB)', 42174, 43698, '', 10, 0, 1, '2019-01-24 06:21:01', NULL),
(15, 40, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/home-slide-2.jpg', '', 'Reduced by 5.6% (4.5 KB)', 77162, 81747, '', 10, 0, 1, '2019-01-24 06:52:27', NULL),
(16, 40, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/home-slide-2-150x150.jpg', '', 'Reduced by 10.1% (825 B)', 7310, 8135, '', 10, 0, 1, '2019-01-24 06:52:28', NULL),
(17, 40, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/home-slide-2-139x300.jpg', '', 'Reduced by 8.9% (825 B)', 8420, 9245, '', 10, 0, 1, '2019-01-24 06:52:29', NULL),
(18, 40, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/home-slide-2-450x600.jpg', '', 'Reduced by 6.2% (4.5 KB)', 70153, 74803, '', 10, 0, 1, '2019-01-24 06:52:30', NULL),
(19, 41, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/home-slide-2-2.jpg', '', 'Reduced by 1.6% (703 B)', 44419, 45122, '', 10, 0, 1, '2019-01-24 06:53:16', NULL),
(20, 41, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/home-slide-2-2-150x150.jpg', '', 'No savings', 4785, 4785, '', 10, 0, 1, '2019-01-24 06:53:17', NULL),
(21, 41, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/home-slide-2-2-139x300.jpg', '', 'No savings', 6826, 6826, '', 10, 0, 1, '2019-01-24 06:53:18', NULL),
(22, 41, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/home-slide-2-2-450x600.jpg', '', 'Reduced by 3.6% (1.5 KB)', 39595, 41089, '', 10, 0, 1, '2019-01-24 06:53:19', NULL),
(23, 42, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/home-slide-3-3.jpg', '', 'Reduced by 1.1% (314 B)', 29088, 29402, '', 10, 0, 1, '2019-01-24 06:53:31', NULL),
(24, 42, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/home-slide-3-3-150x150.jpg', '', 'No savings', 5916, 5916, '', 10, 0, 1, '2019-01-24 06:53:32', NULL),
(25, 42, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/home-slide-3-3-139x300.jpg', '', 'No savings', 5850, 5850, '', 10, 0, 1, '2019-01-24 06:53:33', NULL),
(26, 42, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/home-slide-3-3-450x600.jpg', '', 'Reduced by 2.7% (763 B)', 27411, 28174, '', 10, 0, 1, '2019-01-24 06:53:35', NULL),
(27, 45, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/me-responsive.jpg', '', 'Reduced by 5.9% (2.7 KB)', 44315, 47087, '', 10, 0, 1, '2019-01-24 07:02:13', NULL),
(28, 45, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/me-responsive-150x150.jpg', '', 'Reduced by 20.0% (971 B)', 3894, 4865, '', 10, 0, 1, '2019-01-24 07:02:14', NULL),
(29, 45, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/me-responsive-199x300.jpg', '', 'Reduced by 11.0% (971 B)', 7830, 8801, '', 10, 0, 1, '2019-01-24 07:02:15', NULL),
(30, 45, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/me-responsive-480x600.jpg', '', 'Reduced by 6.9% (2.6 KB)', 35663, 38314, '', 10, 0, 1, '2019-01-24 07:02:16', NULL),
(31, 59, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/project-buo.jpg', '', 'Reduced by 0.8% (95 B)', 11574, 11669, '', 10, 0, 1, '2019-01-24 08:40:36', NULL),
(32, 59, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/project-buo-150x150.jpg', '', 'No savings', 3684, 3684, '', 10, 0, 1, '2019-01-24 08:40:37', NULL),
(33, 59, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/project-buo-300x198.jpg', '', 'No savings', 5580, 5580, '', 10, 0, 1, '2019-01-24 08:40:39', NULL),
(34, 69, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/project-akbar.jpg', '', 'Reduced by 1.9% (778 B)', 39894, 40672, '', 10, 0, 1, '2019-01-24 22:53:59', NULL),
(35, 69, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/project-akbar-150x150.jpg', '', 'No savings', 8392, 8392, '', 10, 0, 1, '2019-01-24 22:53:59', NULL),
(36, 69, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/project-akbar-300x198.jpg', '', 'Reduced by 4.5% (900 B)', 19245, 20145, '', 10, 0, 1, '2019-01-24 22:53:59', NULL),
(37, 71, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/project-zooma.jpg', '', 'No savings', 7312, 7312, '', 10, 0, 1, '2019-01-24 22:55:48', NULL),
(38, 71, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/project-zooma-150x150.jpg', '', 'No savings', 2393, 2393, '', 10, 0, 1, '2019-01-24 22:55:49', NULL),
(39, 71, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/project-zooma-300x198.jpg', '', 'No savings', 3742, 3742, '', 10, 0, 1, '2019-01-24 22:55:49', NULL),
(40, 73, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/project-arisens.jpg', '', 'Reduced by 1.3% (191 B)', 14339, 14530, '', 10, 0, 1, '2019-01-24 22:56:26', NULL),
(41, 73, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/project-arisens-150x150.jpg', '', 'No savings', 4518, 4518, '', 10, 0, 1, '2019-01-24 22:56:26', NULL),
(42, 73, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/project-arisens-300x198.jpg', '', 'No savings', 6925, 6925, '', 10, 0, 1, '2019-01-24 22:56:26', NULL),
(43, 75, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/project-vectrum.jpg', '', 'Reduced by 2.1% (564 B)', 25846, 26410, '', 10, 0, 1, '2019-01-24 22:59:41', NULL),
(44, 75, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/project-vectrum-150x150.jpg', '', 'No savings', 5478, 5478, '', 10, 0, 1, '2019-01-24 22:59:42', NULL),
(45, 75, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/project-vectrum-300x198.jpg', '', 'No savings', 11705, 11705, '', 10, 0, 1, '2019-01-24 22:59:42', NULL),
(46, 77, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/photo-1.jpg', '', 'Reduced by 3.7% (2.2 KB)', 59299, 61563, '', 10, 0, 1, '2019-01-24 23:05:47', NULL),
(47, 77, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/photo-1-150x150.jpg', '', 'Reduced by 9.8% (841 B)', 7743, 8584, '', 10, 0, 1, '2019-01-24 23:05:47', NULL),
(48, 77, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/photo-1-240x300.jpg', '', 'Reduced by 6.3% (1.3 KB)', 19628, 20951, '', 10, 0, 1, '2019-01-24 23:05:47', NULL),
(49, 77, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/photo-1-500x600.jpg', '', 'Reduced by 4.7% (3.2 KB)', 65752, 69030, '', 10, 0, 1, '2019-01-24 23:05:47', NULL),
(50, 79, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/photo-2.jpg', '', 'Reduced by 3.2% (1.3 KB)', 40191, 41524, '', 10, 0, 1, '2019-01-24 23:06:05', NULL),
(51, 79, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/photo-2-150x150.jpg', '', 'Reduced by 13.7% (871 B)', 5475, 6346, '', 10, 0, 1, '2019-01-24 23:06:06', NULL),
(52, 79, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/photo-2-240x300.jpg', '', 'Reduced by 6.7% (1,004 B)', 14012, 15016, '', 10, 0, 1, '2019-01-24 23:06:06', NULL),
(53, 79, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/photo-2-500x600.jpg', '', 'Reduced by 3.9% (1.9 KB)', 46731, 48637, '', 10, 0, 1, '2019-01-24 23:06:07', NULL),
(54, 81, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/photo-3.jpg', '', 'Reduced by 2.6% (634 B)', 23614, 24248, '', 10, 0, 1, '2019-01-24 23:06:18', NULL),
(55, 81, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/photo-3-150x150.jpg', '', 'Reduced by 17.8% (871 B)', 4019, 4890, '', 10, 0, 1, '2019-01-24 23:06:18', NULL),
(56, 81, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/photo-3-240x300.jpg', '', 'Reduced by 7.8% (813 B)', 9610, 10423, '', 10, 0, 1, '2019-01-24 23:06:18', NULL),
(57, 81, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/photo-3-500x600.jpg', '', 'Reduced by 2.9% (888 B)', 29517, 30405, '', 10, 0, 1, '2019-01-24 23:06:19', NULL),
(58, 83, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/photo-6.jpg', '', 'Reduced by 4.4% (2.1 KB)', 46070, 48200, '', 10, 0, 1, '2019-01-24 23:06:33', NULL),
(59, 83, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/photo-6-150x150.jpg', '', 'Reduced by 14.3% (871 B)', 5202, 6073, '', 10, 0, 1, '2019-01-24 23:06:33', NULL),
(60, 83, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/photo-6-240x300.jpg', '', 'Reduced by 7.1% (1.0 KB)', 13837, 14890, '', 10, 0, 1, '2019-01-24 23:06:33', NULL),
(61, 83, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/photo-6-500x600.jpg', '', 'Reduced by 4.6% (2.6 KB)', 54127, 56747, '', 10, 0, 1, '2019-01-24 23:06:34', NULL),
(62, 85, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/photo-4.jpg', '', 'Reduced by 3.5% (1.1 KB)', 29652, 30740, '', 10, 0, 1, '2019-01-24 23:06:47', NULL),
(63, 85, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/photo-4-150x150.jpg', '', 'Reduced by 14.4% (871 B)', 5175, 6046, '', 10, 0, 1, '2019-01-24 23:06:48', NULL),
(64, 85, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/photo-4-240x300.jpg', '', 'Reduced by 7.6% (937 B)', 11473, 12410, '', 10, 0, 1, '2019-01-24 23:06:48', NULL),
(65, 85, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/photo-4-500x600.jpg', '', 'Reduced by 4.4% (1.6 KB)', 35686, 37320, '', 10, 0, 1, '2019-01-24 23:06:48', NULL),
(66, 87, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/photo-9.jpg', '', 'Reduced by 2.8% (2.5 KB)', 86766, 89280, '', 10, 0, 1, '2019-01-24 23:07:02', NULL),
(67, 87, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/photo-9-150x150.jpg', '', 'Reduced by 12.9% (825 B)', 5564, 6389, '', 10, 0, 1, '2019-01-24 23:07:02', NULL),
(68, 87, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/photo-9-199x300.jpg', '', 'Reduced by 7.4% (1.1 KB)', 13524, 14602, '', 10, 0, 1, '2019-01-24 23:07:03', NULL),
(69, 87, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/photo-9-550x600.jpg', '', 'Reduced by 3.7% (2.6 KB)', 68875, 71527, '', 10, 0, 1, '2019-01-24 23:07:03', NULL),
(70, 89, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/photo-5.jpg', '', 'Reduced by 5.1% (1.1 KB)', 20568, 21675, '', 10, 0, 1, '2019-01-24 23:07:17', NULL),
(71, 89, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/photo-5-150x150.jpg', '', 'Reduced by 20.4% (871 B)', 3396, 4267, '', 10, 0, 1, '2019-01-24 23:07:17', NULL),
(72, 89, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/photo-5-240x300.jpg', '', 'Reduced by 10.5% (871 B)', 7412, 8283, '', 10, 0, 1, '2019-01-24 23:07:18', NULL),
(73, 89, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/photo-5-500x600.jpg', '', 'Reduced by 4.1% (1.1 KB)', 25866, 26966, '', 10, 0, 1, '2019-01-24 23:07:18', NULL),
(74, 91, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/photo-8.jpg', '', 'Reduced by 2.6% (1.0 KB)', 38906, 39940, '', 10, 0, 1, '2019-01-24 23:07:36', NULL),
(75, 91, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/photo-8-150x150.jpg', '', 'Reduced by 12.9% (871 B)', 5872, 6743, '', 10, 0, 1, '2019-01-24 23:07:36', NULL),
(76, 91, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/photo-8-240x300.jpg', '', 'Reduced by 6.0% (939 B)', 14652, 15591, '', 10, 0, 1, '2019-01-24 23:07:37', NULL),
(77, 91, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/photo-8-500x600.jpg', '', 'Reduced by 3.6% (1.7 KB)', 46166, 47872, '', 10, 0, 1, '2019-01-24 23:07:37', NULL),
(78, 93, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/photo-7.jpg', '', 'Reduced by 1.7% (353 B)', 20845, 21198, '', 10, 0, 1, '2019-01-24 23:07:56', NULL),
(79, 93, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/photo-7-150x150.jpg', '', 'Reduced by 18.3% (871 B)', 3896, 4767, '', 10, 0, 1, '2019-01-24 23:07:56', NULL),
(80, 93, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/photo-7-240x300.jpg', '', 'Reduced by 9.3% (871 B)', 8542, 9413, '', 10, 0, 1, '2019-01-24 23:07:57', NULL),
(81, 93, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/photo-7-500x600.jpg', '', 'Reduced by 3.0% (832 B)', 26618, 27450, '', 10, 0, 1, '2019-01-24 23:07:57', NULL),
(82, 95, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/photo-10.jpg', '', 'Reduced by 4.5% (1.3 KB)', 28545, 29882, '', 10, 0, 1, '2019-01-24 23:08:16', NULL),
(83, 95, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/photo-10-150x150.jpg', '', 'Reduced by 16.9% (825 B)', 4047, 4872, '', 10, 0, 1, '2019-01-24 23:08:17', NULL),
(84, 95, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/photo-10-240x300.jpg', '', 'Reduced by 8.4% (825 B)', 8973, 9798, '', 10, 0, 1, '2019-01-24 23:08:17', NULL),
(85, 95, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/photo-10-550x600.jpg', '', 'Reduced by 3.9% (1.3 KB)', 33443, 34785, '', 10, 0, 1, '2019-01-24 23:08:18', NULL),
(86, 97, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/photo-11.jpg', '', 'Reduced by 6.1% (2.6 KB)', 40431, 43050, '', 10, 0, 1, '2019-01-24 23:08:34', NULL),
(87, 97, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/photo-11-150x150.jpg', '', 'Reduced by 16.6% (825 B)', 4142, 4967, '', 10, 0, 1, '2019-01-24 23:08:34', NULL),
(88, 97, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/photo-11-178x300.jpg', '', 'Reduced by 9.1% (825 B)', 8203, 9028, '', 10, 0, 1, '2019-01-24 23:08:34', NULL),
(89, 97, 'media', 'slideshow', 'ABSPATHwp-content/uploads/2019/01/photo-11-550x600.jpg', '', 'Reduced by 5.7% (2.0 KB)', 34732, 36824, '', 10, 0, 1, '2019-01-24 23:08:35', NULL),
(90, 99, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/photo-12.jpg', '', 'Reduced by 6.8% (917 B)', 12509, 13426, '', 10, 0, 1, '2019-01-24 23:08:50', NULL),
(91, 99, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/photo-12-150x150.jpg', '', 'Reduced by 17.7% (825 B)', 3824, 4649, '', 10, 0, 1, '2019-01-24 23:08:50', NULL),
(92, 99, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/photo-12-300x157.jpg', '', 'Reduced by 12.3% (825 B)', 5883, 6708, '', 10, 0, 1, '2019-01-24 23:08:50', NULL),
(105, 106, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/piso-0.jpg', '', 'No savings', 9590, 9590, '', 10, 0, 1, '2019-01-25 19:12:16', NULL),
(106, 106, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/piso-0-150x150.jpg', '', 'No savings', 2701, 2701, '', 10, 0, 1, '2019-01-25 19:12:17', NULL),
(107, 106, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/piso-0-300x198.jpg', '', 'No savings', 4643, 4643, '', 10, 0, 1, '2019-01-25 19:12:17', NULL),
(108, 107, 'media', 'full', 'ABSPATHwp-content/uploads/2019/01/nomad.jpg', '', 'No savings', 8292, 8292, '', 10, 0, 1, '2019-01-25 19:12:32', NULL),
(109, 107, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2019/01/nomad-150x150.jpg', '', 'No savings', 2709, 2709, '', 10, 0, 1, '2019-01-25 19:12:33', NULL),
(110, 107, 'media', 'medium', 'ABSPATHwp-content/uploads/2019/01/nomad-300x198.jpg', '', 'No savings', 4019, 4019, '', 10, 0, 1, '2019-01-25 19:12:33', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pf_ewwwio_queue`
--

CREATE TABLE `pf_ewwwio_queue` (
  `attachment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `gallery` varchar(10) DEFAULT NULL,
  `scanned` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pf_links`
--

CREATE TABLE `pf_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pf_options`
--

CREATE TABLE `pf_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `pf_options`
--

INSERT INTO `pf_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8888', 'yes'),
(2, 'home', 'http://localhost:8888', 'yes'),
(3, 'blogname', 'Matias Salinas', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'jmsalinas@uc.cl', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:88:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=10&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:4:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:19:\"akismet/akismet.php\";i:2;s:36:\"contact-form-7/wp-contact-form-7.php\";i:3;s:45:\"ewww-image-optimizer/ewww-image-optimizer.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'wp_boilerplate', 'yes'),
(41, 'stylesheet', 'wp_boilerplate', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '43764', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:3:{i:1;a:0:{}i:2;a:4:{s:5:\"title\";s:0:\"\";s:4:\"text\";s:98:\"[contact-form-7 id=\"12\" title=\"Contact form 1\" html_id=\"contact__form\" html_class=\"contact__form\"]\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:1:{s:45:\"ewww-image-optimizer/ewww-image-optimizer.php\";s:30:\"ewww_image_optimizer_uninstall\";}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '10', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '43764', 'yes'),
(94, 'pf_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'sidebars_widgets', 'a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:14:\"contact-widget\";a:1:{i:0;s:6:\"text-2\";}s:14:\"sidebar-widget\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(102, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'cron', 'a:5:{i:1548557276;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1548561939;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1548582476;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1548625691;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(112, 'theme_mods_twentynineteen', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1548194109;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}', 'yes'),
(121, '_site_transient_timeout_browser_0ac1f9240df96b3586c220faef490724', '1548798492', 'no'),
(122, '_site_transient_browser_0ac1f9240df96b3586c220faef490724', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"71.0.3578.98\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(124, 'can_compress_scripts', '0', 'no'),
(137, 'current_theme', 'Desafío Latam', 'yes'),
(138, 'theme_mods_wp_boilerplate', 'a:5:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1548196662;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:14:\"contact-widget\";a:0:{}s:14:\"sidebar-widget\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}s:11:\"custom_logo\";i:6;}', 'yes'),
(139, 'theme_switched', '', 'yes'),
(140, 'page_navigation', 'a:6:{s:10:\"first_text\";s:14:\"&laquo; Inicio\";s:9:\"last_text\";s:11:\"Fin &raquo;\";s:9:\"prev_text\";s:7:\"&laquo;\";s:9:\"next_text\";s:7:\"&raquo;\";s:5:\"style\";s:7:\"default\";s:5:\"align\";s:4:\"left\";}', 'yes'),
(145, '_site_transient_timeout_browser_e0b7751b8040fb7c8de50ddf95d10645', '1548814390', 'no'),
(146, '_site_transient_browser_e0b7751b8040fb7c8de50ddf95d10645', 'a:10:{s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"64.0\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:24:\"https://www.firefox.com/\";s:7:\"img_src\";s:44:\"http://s.w.org/images/browsers/firefox.png?1\";s:11:\"img_src_ssl\";s:45:\"https://s.w.org/images/browsers/firefox.png?1\";s:15:\"current_version\";s:2:\"56\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(151, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.3.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.3.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.0.3-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.0.3-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.0.3\";s:7:\"version\";s:5:\"5.0.3\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1548554930;s:15:\"version_checked\";s:5:\"5.0.3\";s:12:\"translations\";a:0:{}}', 'no'),
(154, 'recently_activated', 'a:1:{s:29:\"wp-mail-smtp/wp_mail_smtp.php\";i:1548355117;}', 'yes'),
(195, 'acf_version', '5.7.10', 'yes'),
(196, 'widget_akismet_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(197, 'wpcf7', 'a:2:{s:7:\"version\";s:5:\"5.1.1\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1548288364;s:7:\"version\";s:5:\"5.1.1\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}', 'yes'),
(198, 'ewww_image_optimizer_relative_migration_status', 'done', 'yes'),
(200, 'ewww_image_optimizer_background_optimization', '1', 'yes'),
(201, 'ewww_image_optimizer_flag_attachments', '', 'no'),
(202, 'ewww_image_optimizer_ngg_attachments', '', 'no'),
(203, 'ewww_image_optimizer_disable_pngout', '1', 'no'),
(204, 'ewww_image_optimizer_optipng_level', '2', 'no'),
(205, 'ewww_image_optimizer_pngout_level', '2', 'no'),
(206, 'ewww_image_optimizer_metadata_remove', '1', 'no'),
(207, 'ewww_image_optimizer_jpg_level', '10', 'no'),
(208, 'ewww_image_optimizer_png_level', '10', 'no'),
(209, 'ewww_image_optimizer_gif_level', '10', 'no'),
(210, 'ewww_image_optimizer_pdf_level', '0', 'no'),
(211, 'exactdn_lossy', '1', 'no'),
(212, 'exactdn_all_the_things', '1', 'no'),
(213, 'ewww_image_optimizer_bulk_resume', '', 'yes'),
(214, 'ewww_image_optimizer_aux_resume', '', 'yes'),
(215, 'ewww_image_optimizer_version', '460.0', 'yes'),
(216, 'ewww_image_optimizer_tracking_notice', '1', 'yes'),
(223, 'ewww_image_optimizer_backup_files', '', 'no'),
(224, 'wp_ewwwio_media_optimize_batch_a', '', 'no'),
(306, 'wp_mail_smtp_initial_version', '1.4.1', 'no'),
(307, 'wp_mail_smtp_version', '1.4.1', 'no'),
(308, 'wp_mail_smtp', 'a:5:{s:4:\"mail\";a:6:{s:10:\"from_email\";s:15:\"jmsalinas@uc.cl\";s:9:\"from_name\";s:14:\"Matias Salinas\";s:6:\"mailer\";s:5:\"gmail\";s:11:\"return_path\";b:1;s:16:\"from_email_force\";b:1;s:15:\"from_name_force\";b:0;}s:4:\"smtp\";a:7:{s:7:\"autotls\";s:3:\"yes\";s:4:\"host\";s:0:\"\";s:10:\"encryption\";s:4:\"none\";s:4:\"port\";s:0:\"\";s:4:\"user\";s:0:\"\";s:4:\"pass\";s:0:\"\";s:4:\"auth\";b:0;}s:5:\"gmail\";a:2:{s:9:\"client_id\";s:12:\"dr.msardinas\";s:13:\"client_secret\";s:12:\"ploplas18467\";}s:7:\"mailgun\";a:3:{s:7:\"api_key\";s:0:\"\";s:6:\"domain\";s:0:\"\";s:6:\"region\";s:2:\"US\";}s:8:\"sendgrid\";a:1:{s:7:\"api_key\";s:0:\"\";}}', 'no'),
(309, '_amn_smtp_last_checked', '1548288000', 'yes'),
(310, 'wp_mail_smtp_debug', 'a:0:{}', 'no'),
(438, '_site_transient_timeout_theme_roots', '1548556733', 'no'),
(439, '_site_transient_theme_roots', 'a:4:{s:14:\"twentynineteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";s:14:\"wp_boilerplate\";s:7:\"/themes\";}', 'no'),
(440, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1548554935;s:7:\"checked\";a:4:{s:14:\"twentynineteen\";s:3:\"1.1\";s:15:\"twentyseventeen\";s:3:\"1.9\";s:13:\"twentysixteen\";s:3:\"1.7\";s:14:\"wp_boilerplate\";s:5:\"1.5.2\";}s:8:\"response\";a:3:{s:14:\"twentynineteen\";a:4:{s:5:\"theme\";s:14:\"twentynineteen\";s:11:\"new_version\";s:3:\"1.2\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentynineteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentynineteen.1.2.zip\";}s:15:\"twentyseventeen\";a:4:{s:5:\"theme\";s:15:\"twentyseventeen\";s:11:\"new_version\";s:3:\"2.0\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentyseventeen/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentyseventeen.2.0.zip\";}s:13:\"twentysixteen\";a:4:{s:5:\"theme\";s:13:\"twentysixteen\";s:11:\"new_version\";s:3:\"1.8\";s:3:\"url\";s:43:\"https://wordpress.org/themes/twentysixteen/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/theme/twentysixteen.1.8.zip\";}}s:12:\"translations\";a:0:{}}', 'no'),
(441, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1548554936;s:7:\"checked\";a:4:{s:30:\"advanced-custom-fields/acf.php\";s:6:\"5.7.10\";s:19:\"akismet/akismet.php\";s:3:\"4.1\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.1.1\";s:45:\"ewww-image-optimizer/ewww-image-optimizer.php\";s:5:\"4.6.0\";}s:8:\"response\";a:1:{s:45:\"ewww-image-optimizer/ewww-image-optimizer.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:34:\"w.org/plugins/ewww-image-optimizer\";s:4:\"slug\";s:20:\"ewww-image-optimizer\";s:6:\"plugin\";s:45:\"ewww-image-optimizer/ewww-image-optimizer.php\";s:11:\"new_version\";s:5:\"4.6.1\";s:3:\"url\";s:51:\"https://wordpress.org/plugins/ewww-image-optimizer/\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/plugin/ewww-image-optimizer.4.6.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/ewww-image-optimizer/assets/icon-256x256.png?rev=1582276\";s:2:\"1x\";s:73:\"https://ps.w.org/ewww-image-optimizer/assets/icon-128x128.png?rev=1582276\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:76:\"https://ps.w.org/ewww-image-optimizer/assets/banner-1544x500.jpg?rev=1582276\";s:2:\"1x\";s:75:\"https://ps.w.org/ewww-image-optimizer/assets/banner-772x250.jpg?rev=1582276\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:3:\"5.1\";s:12:\"requires_php\";s:3:\"5.6\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:3:{s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:6:\"5.7.10\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.5.7.10.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";}s:11:\"banners_rtl\";a:0:{}}s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:3:\"4.1\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/akismet.4.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.1.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.1.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";s:2:\"1x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pf_postmeta`
--

CREATE TABLE `pf_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `pf_postmeta`
--

INSERT INTO `pf_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(5, 6, '_wp_attached_file', '2019/01/cropped-apple-touch-icon-120x120.png'),
(6, 6, '_wp_attachment_context', 'custom-logo'),
(7, 6, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:120;s:6:\"height\";i:120;s:4:\"file\";s:44:\"2019/01/cropped-apple-touch-icon-120x120.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(8, 7, '_wp_trash_meta_status', 'publish'),
(9, 7, '_wp_trash_meta_time', '1548212951'),
(10, 3, '_wp_trash_meta_status', 'draft'),
(11, 3, '_wp_trash_meta_time', '1548216333'),
(12, 3, '_wp_desired_post_slug', 'privacy-policy'),
(13, 2, '_wp_trash_meta_status', 'publish'),
(14, 2, '_wp_trash_meta_time', '1548216335'),
(15, 2, '_wp_desired_post_slug', 'sample-page'),
(16, 10, '_edit_lock', '1548518512:1'),
(17, 10, '_wp_page_template', 'page-home.php'),
(18, 12, '_form', '<div class=\"tab\">\n[text first_name placeholder \"Name\"]\n</div>\n<div class=\"tab\">\n[email* email placeholder \"Email\"]\n</div>\n<div class=\"tab\">\n[text about placeholder \"About (Web, Design, Photography)\"]\n</div>\n<div class=\"tab\">\n[text phone placeholder \"Phone\"]\n</div>\n<div class=\"prevnext__section\">\n<div class=\"prev__next_div\">\n<button type=\"button\" id=\"prevBtn\" onclick=\"nextPrev(-1)\">Previous</button>\n<button type=\"button\" id=\"nextBtn\" onclick=\"nextPrev(1)\">Next</button>\n</div>\n</div>\n\n<div class=\"steps__cont\">\n<span class=\"step\"></span>\n<span class=\"step\"></span>\n<span class=\"step\"></span>\n<span class=\"step\"></span>\n</div>'),
(19, 12, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:9:\"\"[about]\"\";s:6:\"sender\";s:7:\"[email]\";s:9:\"recipient\";s:15:\"jmsalinas@uc.cl\";s:4:\"body\";s:138:\"From: [name] <[email]>\nSubject: [about]\n\n\n-- \nThis e-mail was sent from a contact form on Matias Salinas Portfolio (http://localhost:8888)\";s:18:\"additional_headers\";s:0:\"\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(20, 12, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:31:\"Matias Salinas \"[your-subject]\"\";s:6:\"sender\";s:32:\"Matias Salinas <jmsalinas@uc.cl>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:116:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Matias Salinas (http://localhost:8888)\";s:18:\"additional_headers\";s:25:\"Reply-To: jmsalinas@uc.cl\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(21, 12, '_messages', 'a:23:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}'),
(22, 12, '_additional_settings', ''),
(23, 12, '_locale', 'en_US'),
(24, 13, '_edit_last', '1'),
(25, 13, '_edit_lock', '1548302239:1'),
(26, 19, '_edit_last', '1'),
(27, 19, '_edit_lock', '1548434248:1'),
(28, 24, '_wp_attached_file', '2019/01/apple-touch-icon-180x180.png'),
(29, 24, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:180;s:6:\"height\";i:180;s:4:\"file\";s:36:\"2019/01/apple-touch-icon-180x180.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"apple-touch-icon-180x180-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(30, 10, '_edit_last', '1'),
(31, 10, 'logo', '24'),
(32, 10, '_logo', 'field_5c492bec88e60'),
(33, 10, 'title_home', 'Hi,\r\nI´m Matias,\r\nDesigner.'),
(34, 10, '_title_home', 'field_5c492c184a71e'),
(35, 10, 'name_home', 'MATIASSALINAS'),
(36, 10, '_name_home', 'field_5c492c8fc487a'),
(37, 10, 'description_home', 'GRAPHIC DESIGN - WEB DEVELOPMENT'),
(38, 10, '_description_home', 'field_5c492cdf24d4c'),
(39, 25, 'logo', '24'),
(40, 25, '_logo', 'field_5c492bec88e60'),
(41, 25, 'title_home', 'Hi,\r\nI´m Matias,\r\nDesigner.'),
(42, 25, '_title_home', 'field_5c492c184a71e'),
(43, 25, 'name_home', 'MATIASSALINAS'),
(44, 25, '_name_home', 'field_5c492c8fc487a'),
(45, 25, 'description_home', 'GRAPHIC DESIGN - WEB DEVELOPMENT'),
(46, 25, '_description_home', 'field_5c492cdf24d4c'),
(47, 27, '_wp_attached_file', '2019/01/home-slide-3.jpg'),
(48, 27, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:450;s:6:\"height\";i:974;s:4:\"file\";s:24:\"2019/01/home-slide-3.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"home-slide-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"home-slide-3-139x300.jpg\";s:5:\"width\";i:139;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:24:\"home-slide-3-450x600.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:24:\"home-slide-3-450x600.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(49, 28, '_edit_last', '1'),
(50, 28, 'slide_photo', '27'),
(51, 28, '_slide_photo', 'field_5c49082173994'),
(52, 28, 'slide_class', 'slide-3'),
(53, 28, '_slide_class', 'field_5c49084c73995'),
(54, 28, '_edit_lock', '1548299828:1'),
(55, 30, '_wp_attached_file', '2019/01/home-slide-1.jpg'),
(56, 30, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:450;s:6:\"height\";i:974;s:4:\"file\";s:24:\"2019/01/home-slide-1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"home-slide-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"home-slide-1-139x300.jpg\";s:5:\"width\";i:139;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:24:\"home-slide-1-450x600.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:24:\"home-slide-1-450x600.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(57, 29, '_edit_last', '1'),
(58, 29, 'slide_photo', '30'),
(59, 29, '_slide_photo', 'field_5c49082173994'),
(60, 29, 'slide_class', 'slide-1'),
(61, 29, '_slide_class', 'field_5c49084c73995'),
(62, 29, '_edit_lock', '1548301436:1'),
(63, 31, '_edit_last', '1'),
(64, 31, '_edit_lock', '1548300195:1'),
(65, 32, '_wp_attached_file', '2019/01/home-slide-1-1.jpg'),
(66, 32, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:450;s:6:\"height\";i:974;s:4:\"file\";s:26:\"2019/01/home-slide-1-1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"home-slide-1-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"home-slide-1-1-139x300.jpg\";s:5:\"width\";i:139;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:26:\"home-slide-1-1-450x600.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:26:\"home-slide-1-1-450x600.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(67, 31, 'slide_photo', '32'),
(68, 31, '_slide_photo', 'field_5c49082173994'),
(69, 31, 'slide_class', 'slide-1-1'),
(70, 31, '_slide_class', 'field_5c49084c73995'),
(71, 31, '_wp_trash_meta_status', 'publish'),
(72, 31, '_wp_trash_meta_time', '1548301737'),
(73, 31, '_wp_desired_post_slug', 'slide-1-1'),
(74, 29, '_wp_trash_meta_status', 'publish'),
(75, 29, '_wp_trash_meta_time', '1548301742'),
(76, 29, '_wp_desired_post_slug', 'slide-1'),
(77, 28, '_wp_trash_meta_status', 'publish'),
(78, 28, '_wp_trash_meta_time', '1548301746'),
(79, 28, '_wp_desired_post_slug', '28'),
(80, 40, '_wp_attached_file', '2019/01/home-slide-2.jpg'),
(81, 40, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:450;s:6:\"height\";i:974;s:4:\"file\";s:24:\"2019/01/home-slide-2.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"home-slide-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"home-slide-2-139x300.jpg\";s:5:\"width\";i:139;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:24:\"home-slide-2-450x600.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:24:\"home-slide-2-450x600.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(82, 41, '_wp_attached_file', '2019/01/home-slide-2-2.jpg'),
(83, 41, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:450;s:6:\"height\";i:974;s:4:\"file\";s:26:\"2019/01/home-slide-2-2.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"home-slide-2-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"home-slide-2-2-139x300.jpg\";s:5:\"width\";i:139;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:26:\"home-slide-2-2-450x600.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:26:\"home-slide-2-2-450x600.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(84, 42, '_wp_attached_file', '2019/01/home-slide-3-3.jpg'),
(85, 42, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:450;s:6:\"height\";i:974;s:4:\"file\";s:26:\"2019/01/home-slide-3-3.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"home-slide-3-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"home-slide-3-3-139x300.jpg\";s:5:\"width\";i:139;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:26:\"home-slide-3-3-450x600.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:26:\"home-slide-3-3-450x600.jpg\";s:5:\"width\";i:450;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(86, 39, '_edit_last', '1'),
(87, 39, 'slide_photo', ''),
(88, 39, '_slide_photo', 'field_5c49082173994'),
(89, 39, 'slide_class', 'slide-1'),
(90, 39, '_slide_class', 'field_5c49084c73995'),
(91, 39, 'slide_1', '30'),
(92, 39, '_slide_1', 'field_5c49353688cab'),
(93, 39, 'slide_2', '40'),
(94, 39, '_slide_2', 'field_5c49354988cac'),
(95, 39, 'slide_3', '27'),
(96, 39, '_slide_3', 'field_5c49355e88cad'),
(97, 39, 'slide_1_1', '32'),
(98, 39, '_slide_1_1', 'field_5c49357188cae'),
(99, 39, 'slide_2_2', '41'),
(100, 39, '_slide_2_2', 'field_5c49358188caf'),
(101, 39, 'slide_3_3', '42'),
(102, 39, '_slide_3_3', 'field_5c49359188cb0'),
(103, 39, '_edit_lock', '1548434437:1'),
(104, 45, '_wp_attached_file', '2019/01/me-responsive.jpg'),
(105, 45, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:480;s:6:\"height\";i:725;s:4:\"file\";s:25:\"2019/01/me-responsive.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"me-responsive-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"me-responsive-199x300.jpg\";s:5:\"width\";i:199;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:25:\"me-responsive-480x600.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:25:\"me-responsive-480x600.jpg\";s:5:\"width\";i:480;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(106, 10, 'me_bkg_responsive', '45'),
(107, 10, '_me_bkg_responsive', 'field_5c49383841c04'),
(108, 10, '_', 'field_5c493a7abdcfb'),
(109, 46, 'logo', '24'),
(110, 46, '_logo', 'field_5c492bec88e60'),
(111, 46, 'title_home', 'Hi,\r\nI´m Matias,\r\nDesigner.'),
(112, 46, '_title_home', 'field_5c492c184a71e'),
(113, 46, 'name_home', 'MATIASSALINAS'),
(114, 46, '_name_home', 'field_5c492c8fc487a'),
(115, 46, 'description_home', 'GRAPHIC DESIGN - WEB DEVELOPMENT'),
(116, 46, '_description_home', 'field_5c492cdf24d4c'),
(117, 46, 'me_bkg_responsive', '45'),
(118, 46, '_me_bkg_responsive', 'field_5c49383841c04'),
(119, 48, '_edit_last', '1'),
(120, 48, '_edit_lock', '1548303850:1'),
(121, 10, 'timeline_title', 'I\'m Matias, a freelance\r\ndeveloper & designer.'),
(122, 10, '_timeline_title', 'field_5c49389541c05'),
(123, 46, 'timeline_title', 'I\'m Matias, a freelance\r\ndeveloper & designer.'),
(124, 46, '_timeline_title', 'field_5c49389541c05'),
(125, 51, '_edit_last', '1'),
(126, 51, 'date', '1993'),
(127, 51, '_date', 'field_5c493d752cc33'),
(128, 51, 'event_description', 'Born Santiago, Chile.'),
(129, 51, '_event_description', 'field_5c493da52cc34'),
(130, 51, '_edit_lock', '1548434566:1'),
(131, 52, '_edit_last', '1'),
(132, 52, '_edit_lock', '1548304804:1'),
(133, 52, 'date', '2017'),
(134, 52, '_date', 'field_5c493d752cc33'),
(135, 52, 'event_description', 'Design Graduate School'),
(136, 52, '_event_description', 'field_5c493da52cc34'),
(137, 53, '_edit_last', '1'),
(138, 53, '_edit_lock', '1548304811:1'),
(139, 53, 'date', '2018'),
(140, 53, '_date', 'field_5c493d752cc33'),
(141, 53, 'event_description', 'Front-End Bootcamp in Desafío Latam developers academy\r\n\r\nExternal consultant in Zooma Diseño, design studio based in Santiago, Chile.\r\n\r\nFreelancer experience in cooperation with several agenies, companies and professionals from Chile.'),
(142, 53, '_event_description', 'field_5c493da52cc34'),
(143, 10, 'skill_description', 'The area that I enjoy the most is front-end web development, taking a close approach with the client in order to bring his vision to the design.\r\n\r\nAs a designer I’m insterested in graphic solutions and visual information, which comes in handy for the web design process as well. Some of my work also includes branding for companies or campaigns.\r\n\r\nAs a side passion of mine, I’ve come to develop an interest in portrait photography, especially the ones placed in urban environments.'),
(144, 10, '_skill_description', 'field_5c493a7abdcfb'),
(145, 46, 'skill_description', 'The area that I enjoy the most is front-end web development, taking a close approach with the client in order to bring his vision to the design.\r\n\r\nAs a designer I’m insterested in graphic solutions and visual information, which comes in handy for the web design process as well. Some of my work also includes branding for companies or campaigns.\r\n\r\nAs a side passion of mine, I’ve come to develop an interest in portrait photography, especially the ones placed in urban environments.'),
(146, 46, '_skill_description', 'field_5c493a7abdcfb'),
(147, 54, '_edit_last', '1'),
(148, 54, '_edit_lock', '1548308252:1'),
(149, 58, '_edit_last', '1'),
(150, 58, '_edit_lock', '1548332831:1'),
(151, 59, '_wp_attached_file', '2019/01/project-buo.jpg'),
(152, 59, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:330;s:4:\"file\";s:23:\"2019/01/project-buo.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"project-buo-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"project-buo-300x198.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:198;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(153, 58, 'web_project_img', '59'),
(154, 58, '_web_project_img', 'field_5c494d368f10f'),
(155, 58, 'web_project_description', 'Event Planner Company based in Santiago, Chile since 2008'),
(156, 58, '_web_project_description', 'field_5c494d6a524bb'),
(157, 58, 'web_project_url', 'http://buo.cl/'),
(158, 58, '_web_project_url', 'field_5c494daa524bc'),
(159, 60, '_edit_last', '1'),
(160, 60, '_edit_lock', '1548344811:1'),
(161, 62, '_edit_last', '1'),
(162, 62, '_edit_lock', '1548347144:1'),
(163, 10, 'contact_mail', 'jmsalinas@uc.cl'),
(164, 10, '_contact_mail', 'field_5c49e79fa802a'),
(165, 10, 'contact_mail_link', 'jmsalinas@uc.cl'),
(166, 10, '_contact_mail_link', 'field_5c49e7c8a802b'),
(167, 10, 'contact_phone', '+56944139618'),
(168, 10, '_contact_phone', 'field_5c49e7f2a802c'),
(169, 10, 'contact_phone_link', '+56944139618'),
(170, 10, '_contact_phone_link', 'field_5c49e80aa802d'),
(171, 46, 'contact_mail', 'jmsalinas@uc.cl'),
(172, 46, '_contact_mail', 'field_5c49e79fa802a'),
(173, 46, 'contact_mail_link', 'jmsalinas@uc.cl'),
(174, 46, '_contact_mail_link', 'field_5c49e7c8a802b'),
(175, 46, 'contact_phone', '+56944139618'),
(176, 46, '_contact_phone', 'field_5c49e7f2a802c'),
(177, 46, 'contact_phone_link', '+56944139618'),
(178, 46, '_contact_phone_link', 'field_5c49e80aa802d'),
(186, 68, '_edit_last', '1'),
(187, 68, '_edit_lock', '1548359587:1'),
(188, 69, '_wp_attached_file', '2019/01/project-akbar.jpg'),
(189, 69, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:330;s:4:\"file\";s:25:\"2019/01/project-akbar.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"project-akbar-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"project-akbar-300x198.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:198;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(190, 68, 'web_project_img', '69'),
(191, 68, '_web_project_img', 'field_5c494d368f10f'),
(192, 68, 'web_project_description', 'Web development for International Tea company based in India, Akbar S.A'),
(193, 68, '_web_project_description', 'field_5c494d6a524bb'),
(194, 68, 'web_project_url', 'http://akbarchile.cl/'),
(195, 68, '_web_project_url', 'field_5c494daa524bc'),
(196, 70, '_edit_last', '1'),
(197, 70, '_edit_lock', '1548359625:1'),
(198, 71, '_wp_attached_file', '2019/01/project-zooma.jpg'),
(199, 71, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:330;s:4:\"file\";s:25:\"2019/01/project-zooma.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"project-zooma-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"project-zooma-300x198.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:198;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(200, 70, 'web_project_img', '71'),
(201, 70, '_web_project_img', 'field_5c494d368f10f'),
(202, 70, 'web_project_description', 'Design Studio based in Santiago, Chile.'),
(203, 70, '_web_project_description', 'field_5c494d6a524bb'),
(204, 70, 'web_project_url', 'http://zooma.cl/'),
(205, 70, '_web_project_url', 'field_5c494daa524bc'),
(206, 72, '_edit_last', '1'),
(207, 72, '_edit_lock', '1548359816:1'),
(208, 73, '_wp_attached_file', '2019/01/project-arisens.jpg'),
(209, 73, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:330;s:4:\"file\";s:27:\"2019/01/project-arisens.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"project-arisens-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"project-arisens-300x198.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:198;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(210, 72, 'web_project_img', '73'),
(211, 72, '_web_project_img', 'field_5c494d368f10f'),
(212, 72, 'web_project_description', 'Industrial robotic solutions for industries 4.0'),
(213, 72, '_web_project_description', 'field_5c494d6a524bb'),
(214, 72, 'web_project_url', 'https://www.arisens.cl/'),
(215, 72, '_web_project_url', 'field_5c494daa524bc'),
(216, 74, '_edit_last', '1'),
(217, 74, '_edit_lock', '1548434602:1'),
(218, 75, '_wp_attached_file', '2019/01/project-vectrum.jpg'),
(219, 75, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:330;s:4:\"file\";s:27:\"2019/01/project-vectrum.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"project-vectrum-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"project-vectrum-300x198.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:198;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(220, 74, 'web_project_img', '75'),
(221, 74, '_web_project_img', 'field_5c494d368f10f'),
(222, 74, 'web_project_description', 'Water control systems for industries and housing'),
(223, 74, '_web_project_description', 'field_5c494d6a524bb'),
(224, 74, 'web_project_url', 'http://www.vectrum.cl/'),
(225, 74, '_web_project_url', 'field_5c494daa524bc'),
(226, 77, '_wp_attached_file', '2019/01/photo-1.jpg'),
(227, 77, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:625;s:4:\"file\";s:19:\"2019/01/photo-1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"photo-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"photo-1-240x300.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:19:\"photo-1-500x600.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"photo-1-500x600.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(228, 76, '_edit_last', '1'),
(229, 76, 'photography_img', '77'),
(230, 76, '_photography_img', 'field_5c49e46f83eec'),
(231, 76, '_edit_lock', '1548361459:1'),
(232, 79, '_wp_attached_file', '2019/01/photo-2.jpg'),
(233, 79, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:625;s:4:\"file\";s:19:\"2019/01/photo-2.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"photo-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"photo-2-240x300.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:19:\"photo-2-500x600.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"photo-2-500x600.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(234, 78, '_edit_last', '1'),
(235, 78, 'photography_img', '79'),
(236, 78, '_photography_img', 'field_5c49e46f83eec'),
(237, 78, '_edit_lock', '1548360221:1'),
(238, 81, '_wp_attached_file', '2019/01/photo-3.jpg'),
(239, 81, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:625;s:4:\"file\";s:19:\"2019/01/photo-3.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"photo-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"photo-3-240x300.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:19:\"photo-3-500x600.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"photo-3-500x600.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(240, 80, '_edit_last', '1'),
(241, 80, 'photography_img', '81'),
(242, 80, '_photography_img', 'field_5c49e46f83eec'),
(243, 80, '_edit_lock', '1548360234:1'),
(244, 83, '_wp_attached_file', '2019/01/photo-6.jpg'),
(245, 83, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:625;s:4:\"file\";s:19:\"2019/01/photo-6.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"photo-6-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"photo-6-240x300.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:19:\"photo-6-500x600.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"photo-6-500x600.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(246, 82, '_edit_last', '1'),
(247, 82, 'photography_img', '83'),
(248, 82, '_photography_img', 'field_5c49e46f83eec'),
(249, 82, '_edit_lock', '1548360249:1'),
(250, 85, '_wp_attached_file', '2019/01/photo-4.jpg'),
(251, 85, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:625;s:4:\"file\";s:19:\"2019/01/photo-4.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"photo-4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"photo-4-240x300.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:19:\"photo-4-500x600.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"photo-4-500x600.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(252, 84, '_edit_last', '1'),
(253, 84, 'photography_img', '85'),
(254, 84, '_photography_img', 'field_5c49e46f83eec'),
(255, 84, '_edit_lock', '1548360263:1'),
(256, 87, '_wp_attached_file', '2019/01/photo-9.jpg'),
(257, 87, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:550;s:6:\"height\";i:830;s:4:\"file\";s:19:\"2019/01/photo-9.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"photo-9-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"photo-9-199x300.jpg\";s:5:\"width\";i:199;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:19:\"photo-9-550x600.jpg\";s:5:\"width\";i:550;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"photo-9-550x600.jpg\";s:5:\"width\";i:550;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(258, 86, '_edit_last', '1'),
(259, 86, 'photography_img', '87'),
(260, 86, '_photography_img', 'field_5c49e46f83eec'),
(261, 86, '_edit_lock', '1548360279:1'),
(262, 89, '_wp_attached_file', '2019/01/photo-5.jpg'),
(263, 89, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:625;s:4:\"file\";s:19:\"2019/01/photo-5.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"photo-5-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"photo-5-240x300.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:19:\"photo-5-500x600.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"photo-5-500x600.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(264, 88, '_edit_last', '1'),
(265, 88, 'photography_img', '89'),
(266, 88, '_photography_img', 'field_5c49e46f83eec'),
(267, 88, '_edit_lock', '1548360293:1'),
(268, 91, '_wp_attached_file', '2019/01/photo-8.jpg'),
(269, 91, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:625;s:4:\"file\";s:19:\"2019/01/photo-8.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"photo-8-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"photo-8-240x300.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:19:\"photo-8-500x600.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"photo-8-500x600.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(270, 90, '_edit_last', '1'),
(271, 90, 'photography_img', '91'),
(272, 90, '_photography_img', 'field_5c49e46f83eec'),
(273, 90, '_edit_lock', '1548360313:1'),
(274, 93, '_wp_attached_file', '2019/01/photo-7.jpg'),
(275, 93, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:625;s:4:\"file\";s:19:\"2019/01/photo-7.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"photo-7-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"photo-7-240x300.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:19:\"photo-7-500x600.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"photo-7-500x600.jpg\";s:5:\"width\";i:500;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(276, 92, '_edit_last', '1'),
(277, 92, 'photography_img', '93'),
(278, 92, '_photography_img', 'field_5c49e46f83eec'),
(279, 92, '_edit_lock', '1548360333:1'),
(280, 95, '_wp_attached_file', '2019/01/photo-10.jpg'),
(281, 95, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:550;s:6:\"height\";i:688;s:4:\"file\";s:20:\"2019/01/photo-10.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"photo-10-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"photo-10-240x300.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:20:\"photo-10-550x600.jpg\";s:5:\"width\";i:550;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:20:\"photo-10-550x600.jpg\";s:5:\"width\";i:550;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(282, 94, '_edit_last', '1'),
(283, 94, 'photography_img', '95'),
(284, 94, '_photography_img', 'field_5c49e46f83eec'),
(285, 94, '_edit_lock', '1548360353:1'),
(286, 97, '_wp_attached_file', '2019/01/photo-11.jpg'),
(287, 97, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:550;s:6:\"height\";i:929;s:4:\"file\";s:20:\"2019/01/photo-11.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"photo-11-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"photo-11-178x300.jpg\";s:5:\"width\";i:178;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:20:\"photo-11-550x600.jpg\";s:5:\"width\";i:550;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:20:\"photo-11-550x600.jpg\";s:5:\"width\";i:550;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(288, 96, '_edit_last', '1'),
(289, 96, 'photography_img', '97'),
(290, 96, '_photography_img', 'field_5c49e46f83eec'),
(291, 96, '_edit_lock', '1548360370:1'),
(292, 99, '_wp_attached_file', '2019/01/photo-12.jpg'),
(293, 99, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:550;s:6:\"height\";i:288;s:4:\"file\";s:20:\"2019/01/photo-12.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"photo-12-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"photo-12-300x157.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:157;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(294, 98, '_edit_last', '1'),
(295, 98, 'photography_img', '99'),
(296, 98, '_photography_img', 'field_5c49e46f83eec'),
(297, 98, '_edit_lock', '1548434475:1'),
(300, 100, '_edit_last', '1'),
(301, 100, 'design_project_img', '106'),
(302, 100, '_design_project_img', 'field_5c49afc51b117'),
(303, 100, '_edit_lock', '1548432592:1'),
(306, 102, '_edit_last', '1'),
(307, 102, 'design_project_img', '107'),
(308, 102, '_design_project_img', 'field_5c49afc51b117'),
(309, 102, '_edit_lock', '1548434352:1'),
(314, 106, '_wp_attached_file', '2019/01/piso-0.jpg'),
(315, 106, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:330;s:4:\"file\";s:18:\"2019/01/piso-0.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"piso-0-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"piso-0-300x198.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:198;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(316, 107, '_wp_attached_file', '2019/01/nomad.jpg'),
(317, 107, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:330;s:4:\"file\";s:17:\"2019/01/nomad.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"nomad-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"nomad-300x198.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:198;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(318, 10, 'book_isbn', '9781784971571'),
(319, 10, '_book_isbn', 'field_5c4b39d822a7c'),
(320, 109, 'logo', '24'),
(321, 109, '_logo', 'field_5c492bec88e60'),
(322, 109, 'title_home', 'Hi,\r\nI´m Matias,\r\nDesigner.'),
(323, 109, '_title_home', 'field_5c492c184a71e'),
(324, 109, 'name_home', 'MATIASSALINAS'),
(325, 109, '_name_home', 'field_5c492c8fc487a'),
(326, 109, 'description_home', 'GRAPHIC DESIGN - WEB DEVELOPMENT'),
(327, 109, '_description_home', 'field_5c492cdf24d4c'),
(328, 109, 'me_bkg_responsive', '45'),
(329, 109, '_me_bkg_responsive', 'field_5c49383841c04'),
(330, 109, 'timeline_title', 'I\'m Matias, a freelance\r\ndeveloper & designer.'),
(331, 109, '_timeline_title', 'field_5c49389541c05'),
(332, 109, 'skill_description', 'The area that I enjoy the most is front-end web development, taking a close approach with the client in order to bring his vision to the design.\r\n\r\nAs a designer I’m insterested in graphic solutions and visual information, which comes in handy for the web design process as well. Some of my work also includes branding for companies or campaigns.\r\n\r\nAs a side passion of mine, I’ve come to develop an interest in portrait photography, especially the ones placed in urban environments.'),
(333, 109, '_skill_description', 'field_5c493a7abdcfb'),
(334, 109, 'contact_mail', 'jmsalinas@uc.cl'),
(335, 109, '_contact_mail', 'field_5c49e79fa802a'),
(336, 109, 'contact_mail_link', 'jmsalinas@uc.cl'),
(337, 109, '_contact_mail_link', 'field_5c49e7c8a802b'),
(338, 109, 'contact_phone', '+56944139618'),
(339, 109, '_contact_phone', 'field_5c49e7f2a802c'),
(340, 109, 'contact_phone_link', '+56944139618'),
(341, 109, '_contact_phone_link', 'field_5c49e80aa802d'),
(342, 109, 'book_isbn', '9781784971571'),
(343, 109, '_book_isbn', 'field_5c4b39d822a7c'),
(344, 10, 'map_iframe', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13322.235706819381!2d-70.59778630657789!3d-33.408669680415336!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9662cf4161570681%3A0x8548090720bdbc33!2sD&#39;Fab+Food+Factory!5e0!3m2!1sen!2scl!4v1548123597097\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>'),
(345, 10, '_map_iframe', 'field_5c4b3a96df520'),
(346, 111, 'logo', '24'),
(347, 111, '_logo', 'field_5c492bec88e60'),
(348, 111, 'title_home', 'Hi,\r\nI´m Matias,\r\nDesigner.'),
(349, 111, '_title_home', 'field_5c492c184a71e'),
(350, 111, 'name_home', 'MATIASSALINAS'),
(351, 111, '_name_home', 'field_5c492c8fc487a'),
(352, 111, 'description_home', 'GRAPHIC DESIGN - WEB DEVELOPMENT'),
(353, 111, '_description_home', 'field_5c492cdf24d4c'),
(354, 111, 'me_bkg_responsive', '45'),
(355, 111, '_me_bkg_responsive', 'field_5c49383841c04'),
(356, 111, 'timeline_title', 'I\'m Matias, a freelance\r\ndeveloper & designer.'),
(357, 111, '_timeline_title', 'field_5c49389541c05'),
(358, 111, 'skill_description', 'The area that I enjoy the most is front-end web development, taking a close approach with the client in order to bring his vision to the design.\r\n\r\nAs a designer I’m insterested in graphic solutions and visual information, which comes in handy for the web design process as well. Some of my work also includes branding for companies or campaigns.\r\n\r\nAs a side passion of mine, I’ve come to develop an interest in portrait photography, especially the ones placed in urban environments.'),
(359, 111, '_skill_description', 'field_5c493a7abdcfb'),
(360, 111, 'contact_mail', 'jmsalinas@uc.cl'),
(361, 111, '_contact_mail', 'field_5c49e79fa802a'),
(362, 111, 'contact_mail_link', 'jmsalinas@uc.cl'),
(363, 111, '_contact_mail_link', 'field_5c49e7c8a802b'),
(364, 111, 'contact_phone', '+56944139618'),
(365, 111, '_contact_phone', 'field_5c49e7f2a802c'),
(366, 111, 'contact_phone_link', '+56944139618'),
(367, 111, '_contact_phone_link', 'field_5c49e80aa802d'),
(368, 111, 'book_isbn', '9781784971571'),
(369, 111, '_book_isbn', 'field_5c4b39d822a7c'),
(370, 111, 'map_iframe', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13322.235706819381!2d-70.59778630657789!3d-33.408669680415336!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9662cf4161570681%3A0x8548090720bdbc33!2sD&#39;Fab+Food+Factory!5e0!3m2!1sen!2scl!4v1548123597097\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>'),
(371, 111, '_map_iframe', 'field_5c4b3a96df520');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pf_posts`
--

CREATE TABLE `pf_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `pf_posts`
--

INSERT INTO `pf_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-01-22 21:47:55', '2019-01-22 21:47:55', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2019-01-22 21:47:55', '2019-01-22 21:47:55', '', 0, 'http://localhost:8888/?p=1', 0, 'post', '', 1),
(2, 1, '2019-01-22 21:47:55', '2019-01-22 21:47:55', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost:8888/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2019-01-23 04:05:35', '2019-01-23 04:05:35', '', 0, 'http://localhost:8888/?page_id=2', 0, 'page', '', 0),
(3, 1, '2019-01-22 21:47:55', '2019-01-22 21:47:55', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://localhost:8888.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'trash', 'closed', 'open', '', 'privacy-policy__trashed', '', '', '2019-01-23 04:05:33', '2019-01-23 04:05:33', '', 0, 'http://localhost:8888/?page_id=3', 0, 'page', '', 0),
(4, 1, '2019-01-22 21:48:13', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-01-22 21:48:13', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=4', 0, 'post', '', 0),
(6, 1, '2019-01-23 03:09:05', '2019-01-23 03:09:05', 'http://localhost:8888/wp-content/uploads/2019/01/cropped-apple-touch-icon-120x120.png', 'cropped-apple-touch-icon-120x120.png', '', 'inherit', 'open', 'closed', '', 'cropped-apple-touch-icon-120x120-png', '', '', '2019-01-23 03:09:05', '2019-01-23 03:09:05', '', 0, 'http://localhost:8888/wp-content/uploads/2019/01/cropped-apple-touch-icon-120x120.png', 0, 'attachment', 'image/png', 0),
(7, 1, '2019-01-23 03:09:11', '2019-01-23 03:09:11', '{\n    \"wp_boilerplate::custom_logo\": {\n        \"value\": 6,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-01-23 03:09:11\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'f47986c0-1f41-402e-8b7a-26ffeffe0bbf', '', '', '2019-01-23 03:09:11', '2019-01-23 03:09:11', '', 0, 'http://localhost:8888/2019/01/23/f47986c0-1f41-402e-8b7a-26ffeffe0bbf/', 0, 'customize_changeset', '', 0),
(8, 1, '2019-01-23 04:05:33', '2019-01-23 04:05:33', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://localhost:8888.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2019-01-23 04:05:33', '2019-01-23 04:05:33', '', 3, 'http://localhost:8888/3-revision-v1/', 0, 'revision', '', 0),
(9, 1, '2019-01-23 04:05:35', '2019-01-23 04:05:35', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost:8888/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2019-01-23 04:05:35', '2019-01-23 04:05:35', '', 2, 'http://localhost:8888/2-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2019-01-23 04:06:07', '2019-01-23 04:06:07', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2019-01-25 16:35:51', '2019-01-25 16:35:51', '', 0, 'http://localhost:8888/?page_id=10', 0, 'page', '', 0),
(11, 1, '2019-01-23 04:06:07', '2019-01-23 04:06:07', '', 'Home', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2019-01-23 04:06:07', '2019-01-23 04:06:07', '', 10, 'http://localhost:8888/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2019-01-24 00:06:03', '2019-01-24 00:06:03', '<div class=\"tab\">\r\n[text first_name placeholder \"Name\"]\r\n</div>\r\n<div class=\"tab\">\r\n[email* email placeholder \"Email\"]\r\n</div>\r\n<div class=\"tab\">\r\n[text about placeholder \"About (Web, Design, Photography)\"]\r\n</div>\r\n<div class=\"tab\">\r\n[text phone placeholder \"Phone\"]\r\n</div>\r\n<div class=\"prevnext__section\">\r\n<div class=\"prev__next_div\">\r\n<button type=\"button\" id=\"prevBtn\" onclick=\"nextPrev(-1)\">Previous</button>\r\n<button type=\"button\" id=\"nextBtn\" onclick=\"nextPrev(1)\">Next</button>\r\n</div>\r\n</div>\r\n\r\n<div class=\"steps__cont\">\r\n<span class=\"step\"></span>\r\n<span class=\"step\"></span>\r\n<span class=\"step\"></span>\r\n<span class=\"step\"></span>\r\n</div>\n1\n\"[about]\"\n[email]\njmsalinas@uc.cl\nFrom: [name] <[email]>\r\nSubject: [about]\r\n\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Matias Salinas Portfolio (http://localhost:8888)\n\n\n\n\n\nMatias Salinas \"[your-subject]\"\nMatias Salinas <jmsalinas@uc.cl>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Matias Salinas (http://localhost:8888)\nReply-To: jmsalinas@uc.cl\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nYour entered code is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2019-01-24 19:52:55', '2019-01-24 19:52:55', '', 0, 'http://localhost:8888/?post_type=wpcf7_contact_form&#038;p=12', 0, 'wpcf7_contact_form', '', 0),
(13, 1, '2019-01-24 00:36:24', '2019-01-24 00:36:24', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:10:\"frontslide\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Home Slides', 'home-slides', 'publish', 'closed', 'closed', '', 'group_5c49019895759', '', '', '2019-01-24 03:55:13', '2019-01-24 03:55:13', '', 0, 'http://localhost:8888/?post_type=acf-field-group&#038;p=13', 0, 'acf-field-group', '', 0),
(14, 1, '2019-01-24 00:36:24', '2019-01-24 00:36:24', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:2:\"id\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Slide Photo', 'slide_photo', 'publish', 'closed', 'closed', '', 'field_5c49082173994', '', '', '2019-01-24 03:48:45', '2019-01-24 03:48:45', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=14', 0, 'acf-field', '', 0),
(15, 1, '2019-01-24 00:36:24', '2019-01-24 00:36:24', 'a:13:{s:4:\"type\";s:6:\"select\";s:12:\"instructions\";s:143:\"Choose the slide number in which the image will be displayed. In desktop version, the last 3 slides will be displayed next to the first 3 ones.\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:6:{s:7:\"slide-1\";s:7:\"slide 1\";s:7:\"slide-2\";s:7:\"slide 2\";s:7:\"slide-3\";s:7:\"slide 3\";s:9:\"slide-1-1\";s:9:\"slide 1-1\";s:9:\"slide-2-2\";s:9:\"slide 2-2\";s:9:\"slide-3-3\";s:9:\"slide 3-3\";}s:13:\"default_value\";a:0:{}s:10:\"allow_null\";i:0;s:8:\"multiple\";i:0;s:2:\"ui\";i:0;s:13:\"return_format\";s:5:\"value\";s:4:\"ajax\";i:0;s:11:\"placeholder\";s:0:\"\";}', 'Slide Class', 'slide_class', 'publish', 'closed', 'closed', '', 'field_5c49084c73995', '', '', '2019-01-24 03:48:45', '2019-01-24 03:48:45', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=15', 1, 'acf-field', '', 0),
(16, 1, '2019-01-24 03:03:12', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2019-01-24 03:03:12', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=acf-field-group&p=16', 0, 'acf-field-group', '', 0),
(17, 1, '2019-01-24 03:06:02', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2019-01-24 03:06:02', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=acf-field-group&p=17', 0, 'acf-field-group', '', 0),
(18, 1, '2019-01-24 03:06:17', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2019-01-24 03:06:17', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=acf-field-group&p=18', 0, 'acf-field-group', '', 0),
(19, 1, '2019-01-24 03:08:02', '2019-01-24 03:08:02', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:13:\"page-home.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Portfolio Page', 'portfolio-page', 'publish', 'closed', 'closed', '', 'group_5c492be0420b3', '', '', '2019-01-25 16:36:23', '2019-01-25 16:36:23', '', 0, 'http://localhost:8888/?post_type=acf-field-group&#038;p=19', 0, 'acf-field-group', '', 0),
(20, 1, '2019-01-24 03:08:02', '2019-01-24 03:08:02', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:41:\"Choose the logo to display on the webpage\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Logo', 'logo', 'publish', 'closed', 'closed', '', 'field_5c492bec88e60', '', '', '2019-01-24 03:08:02', '2019-01-24 03:08:02', '', 19, 'http://localhost:8888/?post_type=acf-field&p=20', 0, 'acf-field', '', 0),
(21, 1, '2019-01-24 03:08:50', '2019-01-24 03:08:50', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:64:\"Place the title of the home front page! New lines are supported.\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:28:\"Hi,\r\nI´m Matias,\r\nDesigner.\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:2:\"br\";}', 'Title Home', 'title_home', 'publish', 'closed', 'closed', '', 'field_5c492c184a71e', '', '', '2019-01-24 03:10:01', '2019-01-24 03:10:01', '', 19, 'http://localhost:8888/?post_type=acf-field&#038;p=21', 1, 'acf-field', '', 0),
(22, 1, '2019-01-24 03:11:12', '2019-01-24 03:11:12', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:60:\"Write the name which´ll appear on the top left rotated text\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:13:\"matiassalinas\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Name Home', 'name_home', 'publish', 'closed', 'closed', '', 'field_5c492c8fc487a', '', '', '2019-01-24 03:11:12', '2019-01-24 03:11:12', '', 19, 'http://localhost:8888/?post_type=acf-field&p=22', 2, 'acf-field', '', 0),
(23, 1, '2019-01-24 03:12:14', '2019-01-24 03:12:14', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:69:\"Add the description which will appear at the bottom left rotated text\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:32:\"GRAPHIC DESIGN - WEB DEVELOPMENT\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Description Home', 'description_home', 'publish', 'closed', 'closed', '', 'field_5c492cdf24d4c', '', '', '2019-01-24 03:12:14', '2019-01-24 03:12:14', '', 19, 'http://localhost:8888/?post_type=acf-field&p=23', 3, 'acf-field', '', 0),
(24, 1, '2019-01-24 03:13:59', '2019-01-24 03:13:59', '', 'apple-touch-icon-180x180', '', 'inherit', 'open', 'closed', '', 'apple-touch-icon-180x180', '', '', '2019-01-24 03:13:59', '2019-01-24 03:13:59', '', 10, 'http://localhost:8888/wp-content/uploads/2019/01/apple-touch-icon-180x180.png', 0, 'attachment', 'image/png', 0),
(25, 1, '2019-01-24 03:14:27', '2019-01-24 03:14:27', '', 'Home', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2019-01-24 03:14:27', '2019-01-24 03:14:27', '', 10, 'http://localhost:8888/10-revision-v1/', 0, 'revision', '', 0),
(26, 1, '2019-01-24 03:17:16', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2019-01-24 03:17:16', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=frontslide&p=26', 0, 'frontslide', '', 0),
(27, 1, '2019-01-24 03:18:04', '2019-01-24 03:18:04', '', 'home-slide-3', '', 'inherit', 'open', 'closed', '', 'home-slide-3', '', '', '2019-01-24 03:18:04', '2019-01-24 03:18:04', '', 26, 'http://localhost:8888/wp-content/uploads/2019/01/home-slide-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(28, 1, '2019-01-24 03:19:12', '2019-01-24 03:19:12', '', 'Slide 3', '', 'trash', 'closed', 'closed', '', '28__trashed', '', '', '2019-01-24 03:49:06', '2019-01-24 03:49:06', '', 0, 'http://localhost:8888/?post_type=frontslide&#038;p=28', 0, 'frontslide', '', 0),
(29, 1, '2019-01-24 03:20:18', '2019-01-24 03:20:18', '', 'Slide 1', '', 'trash', 'closed', 'closed', '', 'slide-1__trashed', '', '', '2019-01-24 03:49:02', '2019-01-24 03:49:02', '', 0, 'http://localhost:8888/?post_type=frontslide&#038;p=29', 0, 'frontslide', '', 0),
(30, 1, '2019-01-24 03:19:48', '2019-01-24 03:19:48', '', 'home-slide-1', '', 'inherit', 'open', 'closed', '', 'home-slide-1', '', '', '2019-01-24 03:19:48', '2019-01-24 03:19:48', '', 29, 'http://localhost:8888/wp-content/uploads/2019/01/home-slide-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(31, 1, '2019-01-24 03:21:02', '2019-01-24 03:21:02', '', 'Slide 1 -1', '', 'trash', 'closed', 'closed', '', 'slide-1-1__trashed', '', '', '2019-01-24 03:48:57', '2019-01-24 03:48:57', '', 0, 'http://localhost:8888/?post_type=frontslide&#038;p=31', 0, 'frontslide', '', 0),
(32, 1, '2019-01-24 03:20:50', '2019-01-24 03:20:50', '', 'home-slide-1-1', '', 'inherit', 'open', 'closed', '', 'home-slide-1-1', '', '', '2019-01-24 03:20:50', '2019-01-24 03:20:50', '', 31, 'http://localhost:8888/wp-content/uploads/2019/01/home-slide-1-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(33, 1, '2019-01-24 03:48:45', '2019-01-24 03:48:45', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Slide 1', 'slide_1', 'publish', 'closed', 'closed', '', 'field_5c49353688cab', '', '', '2019-01-24 03:48:45', '2019-01-24 03:48:45', '', 13, 'http://localhost:8888/?post_type=acf-field&p=33', 2, 'acf-field', '', 0),
(34, 1, '2019-01-24 03:48:45', '2019-01-24 03:48:45', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Slide 2', 'slide_2', 'publish', 'closed', 'closed', '', 'field_5c49354988cac', '', '', '2019-01-24 03:48:45', '2019-01-24 03:48:45', '', 13, 'http://localhost:8888/?post_type=acf-field&p=34', 3, 'acf-field', '', 0),
(35, 1, '2019-01-24 03:48:45', '2019-01-24 03:48:45', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Slide 3', 'slide_3', 'publish', 'closed', 'closed', '', 'field_5c49355e88cad', '', '', '2019-01-24 03:55:13', '2019-01-24 03:55:13', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=35', 4, 'acf-field', '', 0),
(36, 1, '2019-01-24 03:48:45', '2019-01-24 03:48:45', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Slide 1 1', 'slide_1_1', 'publish', 'closed', 'closed', '', 'field_5c49357188cae', '', '', '2019-01-24 03:55:13', '2019-01-24 03:55:13', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=36', 5, 'acf-field', '', 0),
(37, 1, '2019-01-24 03:48:45', '2019-01-24 03:48:45', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Slide 2 2', 'slide_2_2', 'publish', 'closed', 'closed', '', 'field_5c49358188caf', '', '', '2019-01-24 03:48:45', '2019-01-24 03:48:45', '', 13, 'http://localhost:8888/?post_type=acf-field&p=37', 6, 'acf-field', '', 0),
(38, 1, '2019-01-24 03:48:45', '2019-01-24 03:48:45', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Slide 3 3', 'slide_3_3', 'publish', 'closed', 'closed', '', 'field_5c49359188cb0', '', '', '2019-01-24 03:55:13', '2019-01-24 03:55:13', '', 13, 'http://localhost:8888/?post_type=acf-field&#038;p=38', 7, 'acf-field', '', 0),
(39, 1, '2019-01-24 03:53:30', '2019-01-24 03:53:30', '', 'Slides', '', 'publish', 'closed', 'closed', '', 'slides', '', '', '2019-01-25 16:42:56', '2019-01-25 16:42:56', '', 0, 'http://localhost:8888/?post_type=frontslide&#038;p=39', 0, 'frontslide', '', 0),
(40, 1, '2019-01-24 03:52:19', '2019-01-24 03:52:19', '', 'home-slide-2', '', 'inherit', 'open', 'closed', '', 'home-slide-2', '', '', '2019-01-24 03:52:19', '2019-01-24 03:52:19', '', 39, 'http://localhost:8888/wp-content/uploads/2019/01/home-slide-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(41, 1, '2019-01-24 03:53:08', '2019-01-24 03:53:08', '', 'home-slide-2-2', '', 'inherit', 'open', 'closed', '', 'home-slide-2-2', '', '', '2019-01-24 03:53:08', '2019-01-24 03:53:08', '', 39, 'http://localhost:8888/wp-content/uploads/2019/01/home-slide-2-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(42, 1, '2019-01-24 03:53:21', '2019-01-24 03:53:21', '', 'home-slide-3-3', '', 'inherit', 'open', 'closed', '', 'home-slide-3-3', '', '', '2019-01-24 03:53:21', '2019-01-24 03:53:21', '', 39, 'http://localhost:8888/wp-content/uploads/2019/01/home-slide-3-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(43, 1, '2019-01-24 04:01:29', '2019-01-24 04:01:29', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:73:\"Place the background image to display in responsive size for \"ME\" section\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Me Bkg Responsive', 'me_bkg_responsive', 'publish', 'closed', 'closed', '', 'field_5c49383841c04', '', '', '2019-01-24 04:01:29', '2019-01-24 04:01:29', '', 19, 'http://localhost:8888/?post_type=acf-field&p=43', 4, 'acf-field', '', 0),
(44, 1, '2019-01-24 04:01:29', '2019-01-24 04:01:29', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:63:\"Title for the timeline from Me section. New lines are supported\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:46:\"I\'m Matias, a freelance\r\ndeveloper & designer.\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:2:\"br\";}', 'Timeline Title', 'timeline_title', 'publish', 'closed', 'closed', '', 'field_5c49389541c05', '', '', '2019-01-24 04:09:36', '2019-01-24 04:09:36', '', 19, 'http://localhost:8888/?post_type=acf-field&#038;p=44', 5, 'acf-field', '', 0),
(45, 1, '2019-01-24 04:02:03', '2019-01-24 04:02:03', '', 'me-responsive', '', 'inherit', 'open', 'closed', '', 'me-responsive', '', '', '2019-01-24 04:02:03', '2019-01-24 04:02:03', '', 10, 'http://localhost:8888/wp-content/uploads/2019/01/me-responsive.jpg', 0, 'attachment', 'image/jpeg', 0),
(46, 1, '2019-01-24 04:02:14', '2019-01-24 04:02:14', '', 'Home', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2019-01-24 04:02:14', '2019-01-24 04:02:14', '', 10, 'http://localhost:8888/10-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2019-01-24 04:09:36', '2019-01-24 04:09:36', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:34:\"Description for the skills section\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:488:\"The area that I enjoy the most is front-end web development, taking a close approach with the client in order to bring his vision to the design.\r\n\r\nAs a designer I’m insterested in graphic solutions and visual information, which comes in handy for the web design process as well. Some of my work also includes branding for companies or campaigns.\r\n\r\nAs a side passion of mine, I’ve come to develop an interest in portrait photography, especially the ones placed in urban environments.\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:2:\"br\";}', 'Skill Description', 'skill_description', 'publish', 'closed', 'closed', '', 'field_5c493a7abdcfb', '', '', '2019-01-24 04:47:59', '2019-01-24 04:47:59', '', 19, 'http://localhost:8888/?post_type=acf-field&#038;p=47', 6, 'acf-field', '', 0),
(48, 1, '2019-01-24 04:24:03', '2019-01-24 04:24:03', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:14:\"timeline_event\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Timeline Event', 'timeline-event', 'publish', 'closed', 'closed', '', 'group_5c493d68656fa', '', '', '2019-01-24 04:26:23', '2019-01-24 04:26:23', '', 0, 'http://localhost:8888/?post_type=acf-field-group&#038;p=48', 0, 'acf-field-group', '', 0),
(49, 1, '2019-01-24 04:24:04', '2019-01-24 04:24:04', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:46:\"Set a date for an important event in your life\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Date', 'date', 'publish', 'closed', 'closed', '', 'field_5c493d752cc33', '', '', '2019-01-24 04:24:04', '2019-01-24 04:24:04', '', 48, 'http://localhost:8888/?post_type=acf-field&p=49', 0, 'acf-field', '', 0),
(50, 1, '2019-01-24 04:24:04', '2019-01-24 04:24:04', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:66:\"Shortly describe the event. New lines will show in the final page.\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:2:\"br\";}', 'Event Description', 'event_description', 'publish', 'closed', 'closed', '', 'field_5c493da52cc34', '', '', '2019-01-24 04:24:04', '2019-01-24 04:24:04', '', 48, 'http://localhost:8888/?post_type=acf-field&p=50', 1, 'acf-field', '', 0),
(51, 1, '2019-01-24 04:30:53', '2019-01-24 04:30:53', '', '1993', '', 'publish', 'closed', 'closed', '', '1993', '', '', '2019-01-24 04:41:02', '2019-01-24 04:41:02', '', 0, 'http://localhost:8888/?post_type=timeline_event&#038;p=51', 0, 'timeline_event', '', 0),
(52, 1, '2019-01-24 04:28:38', '2019-01-24 04:28:38', '', '2017', '', 'publish', 'closed', 'closed', '', '52', '', '', '2019-01-24 04:40:04', '2019-01-24 04:40:04', '', 0, 'http://localhost:8888/?post_type=timeline_event&#038;p=52', 0, 'timeline_event', '', 0),
(53, 1, '2019-01-24 03:29:33', '2019-01-24 03:29:33', '', '2018', '', 'publish', 'closed', 'closed', '', '2018', '', '', '2019-01-24 04:40:11', '2019-01-24 04:40:11', '', 0, 'http://localhost:8888/?post_type=timeline_event&#038;p=53', 0, 'timeline_event', '', 0),
(54, 1, '2019-01-24 05:30:11', '2019-01-24 05:30:11', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:11:\"web_project\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Web Projects', 'web-projects', 'publish', 'closed', 'closed', '', 'group_5c494d27658ba', '', '', '2019-01-24 05:32:13', '2019-01-24 05:32:13', '', 0, 'http://localhost:8888/?post_type=acf-field-group&#038;p=54', 0, 'acf-field-group', '', 0),
(55, 1, '2019-01-24 05:30:12', '2019-01-24 05:30:12', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:31:\"Set an image for a web project.\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Web Project Img', 'web_project_img', 'publish', 'closed', 'closed', '', 'field_5c494d368f10f', '', '', '2019-01-24 05:30:12', '2019-01-24 05:30:12', '', 54, 'http://localhost:8888/?post_type=acf-field&p=55', 0, 'acf-field', '', 0),
(56, 1, '2019-01-24 05:32:13', '2019-01-24 05:32:13', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:36:\"Shortly describe the projects nature\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Web Project Description', 'web_project_description', 'publish', 'closed', 'closed', '', 'field_5c494d6a524bb', '', '', '2019-01-24 05:32:13', '2019-01-24 05:32:13', '', 54, 'http://localhost:8888/?post_type=acf-field&p=56', 1, 'acf-field', '', 0),
(57, 1, '2019-01-24 05:32:13', '2019-01-24 05:32:13', 'a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:31:\"Set an url to the projects link\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}', 'Web Project Url', 'web_project_url', 'publish', 'closed', 'closed', '', 'field_5c494daa524bc', '', '', '2019-01-24 05:32:13', '2019-01-24 05:32:13', '', 54, 'http://localhost:8888/?post_type=acf-field&p=57', 2, 'acf-field', '', 0),
(58, 1, '2019-01-24 05:41:24', '2019-01-24 05:41:24', '', 'Buo', '', 'publish', 'closed', 'closed', '', 'buo', '', '', '2019-01-24 05:41:24', '2019-01-24 05:41:24', '', 0, 'http://localhost:8888/?post_type=web_project&#038;p=58', 0, 'web_project', '', 0),
(59, 1, '2019-01-24 05:40:24', '2019-01-24 05:40:24', '', 'project-buo', '', 'inherit', 'open', 'closed', '', 'project-buo', '', '', '2019-01-24 05:40:24', '2019-01-24 05:40:24', '', 58, 'http://localhost:8888/wp-content/uploads/2019/01/project-buo.jpg', 0, 'attachment', 'image/jpeg', 0),
(60, 1, '2019-01-24 12:30:41', '2019-01-24 12:30:41', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:14:\"design_project\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Design Projects', 'design-projects', 'publish', 'closed', 'closed', '', 'group_5c49afb8efa52', '', '', '2019-01-24 12:31:27', '2019-01-24 12:31:27', '', 0, 'http://localhost:8888/?post_type=acf-field-group&#038;p=60', 0, 'acf-field-group', '', 0),
(61, 1, '2019-01-24 12:30:41', '2019-01-24 12:30:41', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:42:\"Place an image to show as a design project\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Design Project Img', 'design_project_img', 'publish', 'closed', 'closed', '', 'field_5c49afc51b117', '', '', '2019-01-24 12:30:41', '2019-01-24 12:30:41', '', 60, 'http://localhost:8888/?post_type=acf-field&p=61', 0, 'acf-field', '', 0),
(62, 1, '2019-01-24 16:16:09', '2019-01-24 16:16:09', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:16:\"photography_post\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Photo Masonry', 'photo-masonry', 'publish', 'closed', 'closed', '', 'group_5c49e45fccf51', '', '', '2019-01-24 16:16:09', '2019-01-24 16:16:09', '', 0, 'http://localhost:8888/?post_type=acf-field-group&#038;p=62', 0, 'acf-field-group', '', 0),
(63, 1, '2019-01-24 16:16:09', '2019-01-24 16:16:09', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:92:\"Upload an image for the photo masonry. The photo will adjust automatically to the right size\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Photography Img', 'photography_img', 'publish', 'closed', 'closed', '', 'field_5c49e46f83eec', '', '', '2019-01-24 16:16:09', '2019-01-24 16:16:09', '', 62, 'http://localhost:8888/?post_type=acf-field&p=63', 0, 'acf-field', '', 0),
(64, 1, '2019-01-24 16:31:07', '2019-01-24 16:31:07', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:33:\"Contact mail to display in footer\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:15:\"jmsalinas@uc.cl\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Contact Mail', 'contact_mail', 'publish', 'closed', 'closed', '', 'field_5c49e79fa802a', '', '', '2019-01-24 16:31:07', '2019-01-24 16:31:07', '', 19, 'http://localhost:8888/?post_type=acf-field&p=64', 7, 'acf-field', '', 0),
(65, 1, '2019-01-24 16:31:07', '2019-01-24 16:31:07', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:45:\"Contact mail link to send \'Mailto: attribute\'\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:15:\"jmsalinas@uc.cl\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Contact Mail Link', 'contact_mail_link', 'publish', 'closed', 'closed', '', 'field_5c49e7c8a802b', '', '', '2019-01-24 16:31:48', '2019-01-24 16:31:48', '', 19, 'http://localhost:8888/?post_type=acf-field&#038;p=65', 8, 'acf-field', '', 0),
(66, 1, '2019-01-24 16:31:07', '2019-01-24 16:31:07', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:47:\"Contact phone to be displayed in footer section\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:12:\"+56944139618\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Contact Phone', 'contact_phone', 'publish', 'closed', 'closed', '', 'field_5c49e7f2a802c', '', '', '2019-01-24 16:31:48', '2019-01-24 16:31:48', '', 19, 'http://localhost:8888/?post_type=acf-field&#038;p=66', 9, 'acf-field', '', 0),
(67, 1, '2019-01-24 16:31:07', '2019-01-24 16:31:07', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:38:\"Contact phone to link \"tel: attribute\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:12:\"+56944139618\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Contact Phone Link', 'contact_phone_link', 'publish', 'closed', 'closed', '', 'field_5c49e80aa802d', '', '', '2019-01-24 16:31:48', '2019-01-24 16:31:48', '', 19, 'http://localhost:8888/?post_type=acf-field&#038;p=67', 10, 'acf-field', '', 0);
INSERT INTO `pf_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(68, 1, '2019-01-24 19:55:28', '2019-01-24 19:55:28', '', 'Akbar', '', 'publish', 'closed', 'closed', '', 'akbar', '', '', '2019-01-24 19:55:28', '2019-01-24 19:55:28', '', 0, 'http://localhost:8888/?post_type=web_project&#038;p=68', 0, 'web_project', '', 0),
(69, 1, '2019-01-24 19:53:53', '2019-01-24 19:53:53', '', 'project-akbar', '', 'inherit', 'open', 'closed', '', 'project-akbar', '', '', '2019-01-24 19:53:53', '2019-01-24 19:53:53', '', 68, 'http://localhost:8888/wp-content/uploads/2019/01/project-akbar.jpg', 0, 'attachment', 'image/jpeg', 0),
(70, 1, '2019-01-24 19:56:07', '2019-01-24 19:56:07', '', 'Zooma', '', 'publish', 'closed', 'closed', '', 'zooma', '', '', '2019-01-24 19:56:07', '2019-01-24 19:56:07', '', 0, 'http://localhost:8888/?post_type=web_project&#038;p=70', 0, 'web_project', '', 0),
(71, 1, '2019-01-24 19:55:43', '2019-01-24 19:55:43', '', 'project-zooma', '', 'inherit', 'open', 'closed', '', 'project-zooma', '', '', '2019-01-24 19:55:43', '2019-01-24 19:55:43', '', 70, 'http://localhost:8888/wp-content/uploads/2019/01/project-zooma.jpg', 0, 'attachment', 'image/jpeg', 0),
(72, 1, '2019-01-24 19:56:45', '2019-01-24 19:56:45', '', 'Arisens', '', 'publish', 'closed', 'closed', '', 'arisens', '', '', '2019-01-24 19:56:45', '2019-01-24 19:56:45', '', 0, 'http://localhost:8888/?post_type=web_project&#038;p=72', 0, 'web_project', '', 0),
(73, 1, '2019-01-24 19:56:20', '2019-01-24 19:56:20', '', 'project-arisens', '', 'inherit', 'open', 'closed', '', 'project-arisens', '', '', '2019-01-24 19:56:20', '2019-01-24 19:56:20', '', 72, 'http://localhost:8888/wp-content/uploads/2019/01/project-arisens.jpg', 0, 'attachment', 'image/jpeg', 0),
(74, 1, '2019-01-24 20:00:20', '2019-01-24 20:00:20', '', 'Vectrum', '', 'publish', 'closed', 'closed', '', 'vectrum', '', '', '2019-01-24 20:05:04', '2019-01-24 20:05:04', '', 0, 'http://localhost:8888/?post_type=web_project&#038;p=74', 0, 'web_project', '', 0),
(75, 1, '2019-01-24 19:59:36', '2019-01-24 19:59:36', '', 'project-vectrum', '', 'inherit', 'open', 'closed', '', 'project-vectrum', '', '', '2019-01-24 19:59:36', '2019-01-24 19:59:36', '', 74, 'http://localhost:8888/wp-content/uploads/2019/01/project-vectrum.jpg', 0, 'attachment', 'image/jpeg', 0),
(76, 1, '2019-01-24 20:05:49', '2019-01-24 20:05:49', '', '1', '', 'publish', 'closed', 'closed', '', '1', '', '', '2019-01-24 20:26:39', '2019-01-24 20:26:39', '', 0, 'http://localhost:8888/?post_type=photography_post&#038;p=76', 0, 'photography_post', '', 0),
(77, 1, '2019-01-24 20:05:41', '2019-01-24 20:05:41', '', 'photo-1', '', 'inherit', 'open', 'closed', '', 'photo-1', '', '', '2019-01-24 20:05:41', '2019-01-24 20:05:41', '', 76, 'http://localhost:8888/wp-content/uploads/2019/01/photo-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(78, 1, '2019-01-24 20:06:04', '2019-01-24 20:06:04', '', '2', '', 'publish', 'closed', 'closed', '', '2', '', '', '2019-01-24 20:06:04', '2019-01-24 20:06:04', '', 0, 'http://localhost:8888/?post_type=photography_post&#038;p=78', 0, 'photography_post', '', 0),
(79, 1, '2019-01-24 20:06:00', '2019-01-24 20:06:00', '', 'photo-2', '', 'inherit', 'open', 'closed', '', 'photo-2', '', '', '2019-01-24 20:06:00', '2019-01-24 20:06:00', '', 78, 'http://localhost:8888/wp-content/uploads/2019/01/photo-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(80, 1, '2019-01-24 20:06:16', '2019-01-24 20:06:16', '', '3', '', 'publish', 'closed', 'closed', '', '3', '', '', '2019-01-24 20:06:16', '2019-01-24 20:06:16', '', 0, 'http://localhost:8888/?post_type=photography_post&#038;p=80', 0, 'photography_post', '', 0),
(81, 1, '2019-01-24 20:06:12', '2019-01-24 20:06:12', '', 'photo-3', '', 'inherit', 'open', 'closed', '', 'photo-3', '', '', '2019-01-24 20:06:12', '2019-01-24 20:06:12', '', 80, 'http://localhost:8888/wp-content/uploads/2019/01/photo-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(82, 1, '2019-01-24 20:06:31', '2019-01-24 20:06:31', '', '4', '', 'publish', 'closed', 'closed', '', '4', '', '', '2019-01-24 20:06:31', '2019-01-24 20:06:31', '', 0, 'http://localhost:8888/?post_type=photography_post&#038;p=82', 0, 'photography_post', '', 0),
(83, 1, '2019-01-24 20:06:27', '2019-01-24 20:06:27', '', 'photo-6', '', 'inherit', 'open', 'closed', '', 'photo-6', '', '', '2019-01-24 20:06:27', '2019-01-24 20:06:27', '', 82, 'http://localhost:8888/wp-content/uploads/2019/01/photo-6.jpg', 0, 'attachment', 'image/jpeg', 0),
(84, 1, '2019-01-24 20:06:45', '2019-01-24 20:06:45', '', '5', '', 'publish', 'closed', 'closed', '', '5', '', '', '2019-01-24 20:06:45', '2019-01-24 20:06:45', '', 0, 'http://localhost:8888/?post_type=photography_post&#038;p=84', 0, 'photography_post', '', 0),
(85, 1, '2019-01-24 20:06:41', '2019-01-24 20:06:41', '', 'photo-4', '', 'inherit', 'open', 'closed', '', 'photo-4', '', '', '2019-01-24 20:06:41', '2019-01-24 20:06:41', '', 84, 'http://localhost:8888/wp-content/uploads/2019/01/photo-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(86, 1, '2019-01-24 20:07:01', '2019-01-24 20:07:01', '', '6', '', 'publish', 'closed', 'closed', '', '6', '', '', '2019-01-24 20:07:01', '2019-01-24 20:07:01', '', 0, 'http://localhost:8888/?post_type=photography_post&#038;p=86', 0, 'photography_post', '', 0),
(87, 1, '2019-01-24 20:06:56', '2019-01-24 20:06:56', '', 'photo-9', '', 'inherit', 'open', 'closed', '', 'photo-9', '', '', '2019-01-24 20:06:56', '2019-01-24 20:06:56', '', 86, 'http://localhost:8888/wp-content/uploads/2019/01/photo-9.jpg', 0, 'attachment', 'image/jpeg', 0),
(88, 1, '2019-01-24 20:07:15', '2019-01-24 20:07:15', '', '7', '', 'publish', 'closed', 'closed', '', '7', '', '', '2019-01-24 20:07:15', '2019-01-24 20:07:15', '', 0, 'http://localhost:8888/?post_type=photography_post&#038;p=88', 0, 'photography_post', '', 0),
(89, 1, '2019-01-24 20:07:11', '2019-01-24 20:07:11', '', 'photo-5', '', 'inherit', 'open', 'closed', '', 'photo-5', '', '', '2019-01-24 20:07:11', '2019-01-24 20:07:11', '', 88, 'http://localhost:8888/wp-content/uploads/2019/01/photo-5.jpg', 0, 'attachment', 'image/jpeg', 0),
(90, 1, '2019-01-24 20:07:35', '2019-01-24 20:07:35', '', '8', '', 'publish', 'closed', 'closed', '', '8', '', '', '2019-01-24 20:07:35', '2019-01-24 20:07:35', '', 0, 'http://localhost:8888/?post_type=photography_post&#038;p=90', 0, 'photography_post', '', 0),
(91, 1, '2019-01-24 20:07:30', '2019-01-24 20:07:30', '', 'photo-8', '', 'inherit', 'open', 'closed', '', 'photo-8', '', '', '2019-01-24 20:07:30', '2019-01-24 20:07:30', '', 90, 'http://localhost:8888/wp-content/uploads/2019/01/photo-8.jpg', 0, 'attachment', 'image/jpeg', 0),
(92, 1, '2019-01-24 20:07:56', '2019-01-24 20:07:56', '', '9', '', 'publish', 'closed', 'closed', '', '9', '', '', '2019-01-24 20:07:56', '2019-01-24 20:07:56', '', 0, 'http://localhost:8888/?post_type=photography_post&#038;p=92', 0, 'photography_post', '', 0),
(93, 1, '2019-01-24 20:07:50', '2019-01-24 20:07:50', '', 'photo-7', '', 'inherit', 'open', 'closed', '', 'photo-7', '', '', '2019-01-24 20:07:50', '2019-01-24 20:07:50', '', 92, 'http://localhost:8888/wp-content/uploads/2019/01/photo-7.jpg', 0, 'attachment', 'image/jpeg', 0),
(94, 1, '2019-01-24 20:08:15', '2019-01-24 20:08:15', '', '10', '', 'publish', 'closed', 'closed', '', '10', '', '', '2019-01-24 20:08:15', '2019-01-24 20:08:15', '', 0, 'http://localhost:8888/?post_type=photography_post&#038;p=94', 0, 'photography_post', '', 0),
(95, 1, '2019-01-24 20:08:11', '2019-01-24 20:08:11', '', 'photo-10', '', 'inherit', 'open', 'closed', '', 'photo-10', '', '', '2019-01-24 20:08:11', '2019-01-24 20:08:11', '', 94, 'http://localhost:8888/wp-content/uploads/2019/01/photo-10.jpg', 0, 'attachment', 'image/jpeg', 0),
(96, 1, '2019-01-24 20:08:32', '2019-01-24 20:08:32', '', '11', '', 'publish', 'closed', 'closed', '', '11', '', '', '2019-01-24 20:08:32', '2019-01-24 20:08:32', '', 0, 'http://localhost:8888/?post_type=photography_post&#038;p=96', 0, 'photography_post', '', 0),
(97, 1, '2019-01-24 20:08:28', '2019-01-24 20:08:28', '', 'photo-11', '', 'inherit', 'open', 'closed', '', 'photo-11', '', '', '2019-01-24 20:08:28', '2019-01-24 20:08:28', '', 96, 'http://localhost:8888/wp-content/uploads/2019/01/photo-11.jpg', 0, 'attachment', 'image/jpeg', 0),
(98, 1, '2019-01-24 20:08:48', '2019-01-24 20:08:48', '', '12', '', 'publish', 'closed', 'closed', '', '12', '', '', '2019-01-24 20:08:48', '2019-01-24 20:08:48', '', 0, 'http://localhost:8888/?post_type=photography_post&#038;p=98', 0, 'photography_post', '', 0),
(99, 1, '2019-01-24 20:08:45', '2019-01-24 20:08:45', '', 'photo-12', '', 'inherit', 'open', 'closed', '', 'photo-12', '', '', '2019-01-24 20:08:45', '2019-01-24 20:08:45', '', 98, 'http://localhost:8888/wp-content/uploads/2019/01/photo-12.jpg', 0, 'attachment', 'image/jpeg', 0),
(100, 1, '2019-01-25 16:03:00', '2019-01-25 16:03:00', '', 'Piso 0', '', 'publish', 'closed', 'closed', '', '100', '', '', '2019-01-25 16:12:15', '2019-01-25 16:12:15', '', 0, 'http://localhost:8888/?post_type=design_project&#038;p=100', 0, 'design_project', '', 0),
(102, 1, '2019-01-25 16:03:13', '2019-01-25 16:03:13', '', 'Nomad', '', 'publish', 'closed', 'closed', '', '102', '', '', '2019-01-25 16:41:26', '2019-01-25 16:41:26', '', 0, 'http://localhost:8888/?post_type=design_project&#038;p=102', 0, 'design_project', '', 0),
(106, 1, '2019-01-25 16:12:10', '2019-01-25 16:12:10', '', 'piso-0', '', 'inherit', 'open', 'closed', '', 'piso-0', '', '', '2019-01-25 16:12:10', '2019-01-25 16:12:10', '', 100, 'http://localhost:8888/wp-content/uploads/2019/01/piso-0.jpg', 0, 'attachment', 'image/jpeg', 0),
(107, 1, '2019-01-25 16:12:26', '2019-01-25 16:12:26', '', 'nomad', '', 'inherit', 'open', 'closed', '', 'nomad', '', '', '2019-01-25 16:12:26', '2019-01-25 16:12:26', '', 102, 'http://localhost:8888/wp-content/uploads/2019/01/nomad.jpg', 0, 'attachment', 'image/jpeg', 0),
(108, 1, '2019-01-25 16:31:56', '2019-01-25 16:31:56', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:56:\"Get the ISBN code number of the book you want to display\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Book Isbn', 'book_isbn', 'publish', 'closed', 'closed', '', 'field_5c4b39d822a7c', '', '', '2019-01-25 16:31:56', '2019-01-25 16:31:56', '', 19, 'http://localhost:8888/?post_type=acf-field&p=108', 11, 'acf-field', '', 0),
(109, 1, '2019-01-25 16:32:31', '2019-01-25 16:32:31', '', 'Home', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2019-01-25 16:32:31', '2019-01-25 16:32:31', '', 10, 'http://localhost:8888/10-revision-v1/', 0, 'revision', '', 0),
(110, 1, '2019-01-25 16:35:18', '2019-01-25 16:35:18', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:88:\"Place the intere iframe code from google maps embed option. (< iframe > src </ iframe >)\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Map Iframe', 'map_iframe', 'publish', 'closed', 'closed', '', 'field_5c4b3a96df520', '', '', '2019-01-25 16:36:23', '2019-01-25 16:36:23', '', 19, 'http://localhost:8888/?post_type=acf-field&#038;p=110', 12, 'acf-field', '', 0),
(111, 1, '2019-01-25 16:35:51', '2019-01-25 16:35:51', '', 'Home', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2019-01-25 16:35:51', '2019-01-25 16:35:51', '', 10, 'http://localhost:8888/10-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pf_termmeta`
--

CREATE TABLE `pf_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pf_terms`
--

CREATE TABLE `pf_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `pf_terms`
--

INSERT INTO `pf_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pf_term_relationships`
--

CREATE TABLE `pf_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `pf_term_relationships`
--

INSERT INTO `pf_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pf_term_taxonomy`
--

CREATE TABLE `pf_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `pf_term_taxonomy`
--

INSERT INTO `pf_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pf_usermeta`
--

CREATE TABLE `pf_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `pf_usermeta`
--

INSERT INTO `pf_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'matokosp'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'pf_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'pf_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:3:{s:64:\"ab00ef8b445c8b379a485bd02d45badcaf57cd9adfbb7acb24b2aa0045514c55\";a:4:{s:10:\"expiration\";i:1548366491;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36\";s:5:\"login\";i:1548193691;}s:64:\"4abc4caa1ba92bc0b8567391327d5012d120fb94384481920779d669b99ee129\";a:4:{s:10:\"expiration\";i:1548382388;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0\";s:5:\"login\";i:1548209588;}s:64:\"cdce1899999de63a1ad3e4a46aed5cae58ebe62a632e9a7c96b6f5713d4cbfba\";a:4:{s:10:\"expiration\";i:1548527585;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36\";s:5:\"login\";i:1548354785;}}'),
(17, 1, 'pf_user-settings', 'libraryContent=browse&editor=tinymce&mfold=o'),
(18, 1, 'pf_user-settings-time', '1548213219'),
(19, 1, 'pf_dashboard_quick_press_last_post_id', '4'),
(20, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}'),
(21, 1, 'closedpostboxes_frontslide', 'a:2:{i:0;s:11:\"categorydiv\";i:1;s:16:\"tagsdiv-post_tag\";}'),
(22, 1, 'metaboxhidden_frontslide', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(23, 1, 'meta-box-order_frontslide', 'a:4:{s:15:\"acf_after_title\";s:0:\"\";s:4:\"side\";s:38:\"submitdiv,categorydiv,tagsdiv-post_tag\";s:6:\"normal\";s:20:\"slugdiv,postimagediv\";s:8:\"advanced\";s:0:\"\";}'),
(24, 1, 'screen_layout_frontslide', '2');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pf_users`
--

CREATE TABLE `pf_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `pf_users`
--

INSERT INTO `pf_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'matokosp', '$P$BkjVqrHZLQqOaOg563MzveWrhn4nRB.', 'matokosp', 'jmsalinas@uc.cl', '', '2019-01-22 21:47:55', '1548354581:$P$B0ERme/EHWbGkwBxgLl8jKQIf5wJhL/', 0, 'matokosp');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pf_commentmeta`
--
ALTER TABLE `pf_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indices de la tabla `pf_comments`
--
ALTER TABLE `pf_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indices de la tabla `pf_ewwwio_images`
--
ALTER TABLE `pf_ewwwio_images`
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `path` (`path`(191)),
  ADD KEY `attachment_info` (`gallery`(3),`attachment_id`);

--
-- Indices de la tabla `pf_ewwwio_queue`
--
ALTER TABLE `pf_ewwwio_queue`
  ADD KEY `attachment_info` (`gallery`(3),`attachment_id`);

--
-- Indices de la tabla `pf_links`
--
ALTER TABLE `pf_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indices de la tabla `pf_options`
--
ALTER TABLE `pf_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indices de la tabla `pf_postmeta`
--
ALTER TABLE `pf_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indices de la tabla `pf_posts`
--
ALTER TABLE `pf_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indices de la tabla `pf_termmeta`
--
ALTER TABLE `pf_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indices de la tabla `pf_terms`
--
ALTER TABLE `pf_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indices de la tabla `pf_term_relationships`
--
ALTER TABLE `pf_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indices de la tabla `pf_term_taxonomy`
--
ALTER TABLE `pf_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indices de la tabla `pf_usermeta`
--
ALTER TABLE `pf_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indices de la tabla `pf_users`
--
ALTER TABLE `pf_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pf_commentmeta`
--
ALTER TABLE `pf_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `pf_comments`
--
ALTER TABLE `pf_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `pf_ewwwio_images`
--
ALTER TABLE `pf_ewwwio_images`
  MODIFY `id` int(14) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;
--
-- AUTO_INCREMENT de la tabla `pf_links`
--
ALTER TABLE `pf_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `pf_options`
--
ALTER TABLE `pf_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=442;
--
-- AUTO_INCREMENT de la tabla `pf_postmeta`
--
ALTER TABLE `pf_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=372;
--
-- AUTO_INCREMENT de la tabla `pf_posts`
--
ALTER TABLE `pf_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;
--
-- AUTO_INCREMENT de la tabla `pf_termmeta`
--
ALTER TABLE `pf_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `pf_terms`
--
ALTER TABLE `pf_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `pf_term_taxonomy`
--
ALTER TABLE `pf_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `pf_usermeta`
--
ALTER TABLE `pf_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT de la tabla `pf_users`
--
ALTER TABLE `pf_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
